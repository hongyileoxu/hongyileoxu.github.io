# f. vectors_to_matrix(): 
# combine vectors with different length into one matrix with each row for one vector ---- 
## Arg: 
##    vec_list: list: a list of vectors with the same or different lengths. 
##    
## Output: 
##    matrix_combined: matrix: a combined matrix with padding NA for short vectors. 
# 

vectors_to_matrix <- function(vec_list) {
  # Find the maximum length of the vectors in the list
  max_length <- max(sapply(vec_list, length))
  
  # Use sapply to extend each vector to the maximum length by padding with NA
  matrix_combined <- sapply(vec_list, function(x) {
    length(x) <- max_length  # Pad with NA
    return(x)
  }, simplify = FALSE) %>% 
    do.call(what = rbind, args = .)
  
  return(matrix_combined)
}
