# e. filing.item8_notes(): 
# extract raw HTML code for the sub-notes in each Note which matches the required REGEX. 
# extract the information/contents in the notes in <b>Item 8</b>. 
# 
## Arg: 
##    x: Character. The text file in characters. Use the `filing_structured` rather than the `filing`. 
##       The end of each element of the given character should be a closing tag. 
##    loc_item: the location of the item of interest and should be a vector containing two numerical values. 
##       *this input is generated from function `loc.item_MDnA()` or `loc.item()` 
##    item_regex: character: the regex to identify the content of interest. 
##    note_regex: character: the regex to identify the Note of interest. 
##
## Output: 
##    subnote_rawhtml: list: a list of vectors with each element of the list corresponding to the Note of 
##       interest and the name of each element corresponding to the name of that Note. 
##       
## Diagram of Logic: 
##       Q: if the note can be identified by "note_regex" 
##       |--[Yes]-- Q: can we identify the  
##       |    |--[Yes]-- get the sub-note in the identified note(s) 
##       |    |    |--[Yes]-- extract the raw HTML and return(subnote_rawhtml) 
##       |    |    |--[No]--- otherwise, return(NULL) 
##       |    | 
##       |    |--[No]---  no sub-note identified by "note_regex" 
##       |         |-- 
##       |--[No]--- if the note can only be identified by "item_regex" 
#
## 
# For debug:
# {
#   x = filing_structured; # the end of each element should be a closing tag.
#   loc_item = loc_item8$loc_item;
#   item_regex = "\\bpurchas[^\\.]*\\b(obligat|commitment|agreement|order|contract)";
#     # "(?=.*purchas)(?=.*(obligation|commitment|agreement|order|contract))"; # Moon and Phillips (2020)
#   note_regex = NULL; # note_regex = "Note 10"; # which note to look into
# }
## 
# 

filing.item8_notes <- function(x, # filing
                              loc_item, # the location of the item of interest
                              item_regex, # the regex to identify whether the information of interest exists 
                              note_regex = NULL # which note to look into 
) { 
  # `loc_item` cannot be NA! 
  # step 1. extract the text given the information {loc_item, item_id, item, item_id_backup} 
  #     
  # item_txt <- str_squish(paste(x[loc_item[1]:loc_item[2]], collapse = " "))  
  
  # step 2. find the notes
  ### get the cleaned text in blocks. 
  #### cleaned html txt blocks. 
  # item_rawhtml <- clean_html2(input_string = item_txt, pattern = "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])") # *updated Oct 10, 2024  
  item_rawhtml <- x[loc_item[1]:loc_item[2]] 
  
  notes_output <- notes_toc_identify(
    note_pattern = "^note \\d{1,2}", # pattern to identify the Note headers in Item 8 
    note_pattern_extract = "(?i)^.*?\\>note", # the regex to extract the raw HTML information from matched notes
    item_rawhtml = item_rawhtml # a vector of raw HTML characters in Item 8 
  )
  
  if (length(notes_output) == 0) {
    ## even when there are not "Note" found, other header formats exist: e.g. (1); 11.; etc.
    ## https://www.sec.gov/ix?doc=/Archives/edgar/data/822416/000082241619000008/a201810-k.htm 
    ## *updated Oct 18, 2024 
    notes_output <- notes_toc_identify(
      note_pattern = "^\\(?\\d{1,2}\\)?.*(Accounting\\s*Polic)", # pattern to identify the Note headers in Item 8 
      note_pattern_extract = "(?i)^.*?\\>\\(?\\d{1,2}\\)?", # the regex to extract the raw HTML information from matched notes
      item_rawhtml = item_rawhtml # a vector of raw HTML characters in Item 8 
    ) 
    
    if (length(notes_output) == 0) {
      ## Many things to check before return(NULL). 
      return(NULL)
    }
    
  } 
  
  ### unlist the output if outputs are correctly generated and replace old parameters `item_rawhtml`. 
  list2env(x = notes_output, envir = environment()) 
  
  notes_manual <- cbind.data.frame(name = notes_toc, # GO 199
                                   start = notes_tocid, 
                                   end = c((notes_tocid[-1])-1, length(item_rawtxt)) )  
  
  # step 3. identify the "Note" of interest: 
  if (!is.null(note_regex)) {
    # if the input "note_regex" exists 
    whichnote <- grep(pattern = note_regex, x = notes_toc)
    if (length(whichnote) == 0) {
      return(NULL)
    } else {
      item_noteid <- notes_manual[whichnote,] # start-end 
    }
  } else {
    # if the input "note_regex" does not exist 
    ## get the candidate id for the item location in "item_rawhtml": 
    item_noteid_candid <- grep(pattern = item_regex,
                               x = item_rawhtml, ignore.case = TRUE, perl = TRUE) %>% 
      ## exclude matches with "repurch": 
      .[grep(pattern = "repurch", x = item_rawtxt[.], ignore.case = TRUE, invert = TRUE, value = FALSE)] 
    
    res <- try(item_noteid <- notes_manual %>% 
                 mutate(interest = apply(sapply(X = item_noteid_candid,
                                                FUN = function(x) (start <= x & x <= end) ), MARGIN = 1, any)) %>% 
                 filter(interest == TRUE) %>% 
                 select(-interest), silent = TRUE) 
    
    if ((inherits(res, "try-error"))) {
      return(NULL)
    }
    if (dim(item_noteid)[1] == 0) {
      # if no Notes matched: 
      # E.g. "2018/QTR1/20180228_10-K_edgar_data_1364479_0001364479-18-000005.txt" 
      return(NULL) 
    }
  }
  
  # step 4. extract the "Note" and record its table of contents in "subnote_manual". 
  ### get the full html text for the note that I am interested in. 
  note_selected <- apply(item_noteid, MARGIN = 1, FUN = function(x) x["start"]:x["end"], simplify = FALSE) %>% 
    `names<-`(value = item_noteid$name) 
  ### variable `note_raw` contains the raw html code and raw text for the selected matched note(s).
  note_rawhtml <- lapply(X = note_selected, FUN = function(x) {
    rawhtml <- item_rawhtml[x]
    return(rawhtml)
  })
  
  note_rawtxt <- lapply(X = note_selected, FUN = function(x) {
    rawtxt <- item_rawtxt[x]
    return(rawtxt)
  })
  
  ### collect all information into the "subnote_manual".
  #### count the number of words in each block and identify the block as the sub-item header.
  subnote_manual <- sapply(X = note_rawtxt, FUN = function(x) {
    subnote_txtcount <- str_count(string = x, pattern = "[a-zA-Z]+")
    subnote_txtcount[grepl(pattern = "^(\\W)*[a-z]|(\\|)|^[0-9\\s]+$|([Tt]able [Oo]f)|[;$:,]", x = x) |
                       (subnote_txtcount == 0)] <- -1 # exclude strings with (1) "|", (2) not starting with capital letter or (3) no text count.
    subnote_headerid <- which(subnote_txtcount <= 8 & subnote_txtcount > 0) # the row id (relative to `note_rawtxt`) for potential headers, including sub-headers.
    subnote_header <- x[subnote_headerid]
    ## create the manual 
    if (length(subnote_header) == 0) {
      subnote_manual <- cbind.data.frame(
        name = x[1], # record the header for the sub-note
        start = 1, # record the starting line of the sub-note
        end = length(x) # record the ending line of the sub-note
      )
    } else {
      subnote_manual <- cbind.data.frame(
        name = subnote_header, # record the header for the sub-note
        start = subnote_headerid, # record the starting line of the sub-note
        end = c((subnote_headerid[-1])-1, length(x)) # record the ending line of the sub-note
      )
    }
    return(subnote_manual)
  }, USE.NAMES = TRUE, simplify = FALSE)
  
  # step 5. back to the note text to identify the content and the sub-note containing this content
  subnote_contentid <- lapply(X = note_rawtxt, FUN = function(x) {
    output <- grep(pattern = item_regex, x = x, ignore.case = TRUE, perl = TRUE)
    if (length(output) > 0) {
      return(output)
    } else {
      return(NULL)
      # return(invisible(NULL))  # Return nothing (invisible NULL) when x < 0
    }
  }) %>% 
    .[!sapply(., is.null)] 
  
  if (length(subnote_contentid) == 0) {
    ## if no Note(s) contain matched information 
    return(NULL) 
  } 
  
  ## record the HTML for chosen sub-notes under each chosen Note. 
  ## inputs: `subnote_manual` & `subnote_contentid` > output: `subnote_rawhtml` 
  subnote_rawhtml <- sapply(X = names(subnote_contentid), FUN = function(x) {
    # if (!is.null(subnote_contentid[[x]])) {
      ## in a given note, choose the sub-note identified by `subnote_contentid` 
      manual <- subnote_manual[[x]]
      manual_interest <- sapply(X = subnote_contentid[[x]],
                                FUN = function(x) 
                                  (manual$start <= x & x <= manual$end) ) %>% 
        matrix(nrow = dim(manual)[1]) %>% 
        apply(MARGIN = 1, any)
      
      subnote_chosen <- manual[which(manual_interest == TRUE),]
      
      ## extract the raw HTML contents in the sub-note under each note 
      if (dim(subnote_chosen)[1] == 0) {
        return(NULL)
      } 
      subnote_rawhtml <- sapply(X = 1:nrow(subnote_chosen), FUN = function(row) {
        note_rawhtml[[x]][subnote_chosen$start[row]:subnote_chosen$end[row]]
      }, simplify = FALSE, USE.NAMES = FALSE) %>% 
        `names<-`(value = subnote_chosen$name)
      
      return(subnote_rawhtml)
    # } else {
    #   return(NULL) 
    # }
  }, USE.NAMES = TRUE, simplify = FALSE) 
  
  # step 6. return the raw HTML under each Note
  return(subnote_rawhtml) 
} 