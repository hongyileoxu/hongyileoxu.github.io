# find_errors_id(): 
# 
# 
# 


find_errors_id <- function(datafile_fullpath) {
  ### load the data into the function environment 
  load(datafile_fullpath, envir = environment())
  assign("item_purchase_year", get(ls(pattern = "item_purchase_\\d+")) ) 
  
  ### get the list of all files 
  sec_10K_fullpath <- sapply(item_purchase_year, FUN = function(item){
    return(item$file)
  }, simplify = TRUE, USE.NAMES = FALSE) %>% unlist()
  
  ### extract the error terms 
  error_files <- sapply(X = item_purchase_year, FUN = function(item) {
    if (any(item$data == "Error!")) {
      # for an "Error!" output: 
      return(item$file)
    } 
  }, simplify = TRUE, USE.NAMES = FALSE) %>% unlist() 
  # error_files %>% head()
  
  return(list(
    all = sec_10K_fullpath, # the list of ids for all filings. 
    errors = error_files # the ids for filings returning Error! 
  ) )
  
}
