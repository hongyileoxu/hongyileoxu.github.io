# html_to_table(): 
# Convert the extracted raw HTML code to the cleaned long table. 
# Updated: Oct 17, 2024 
# 
## Arg: 
##    tbl_html: xml_document: HTML for the identified table in the XML format. > inherits(x = item_tbls, what = "xml_nodeset")
##    item_html: xml_document: HTML for the full Item/section/Note of interest. 
##    tbl_html_id: numeric: a numerical value to identify the table and default is NULL. 
##    tbl_colname: character: the candidate column name for the item of interest, if that is missing/omitted in the table. 
##    item_regex: character: the REGEX for the item/variable of interest. 
##    allcurrency: logical: if all values in the table are in the currency format, allcurrency = TRUE. 
##    
## Output: 
##    If the table exists: 
##      table: the extracted table in the long format in a n-by-4 matrix. 
##             the table is extrated based on the `item_regex` provided in the input. 
##             each column corresponds to the item, payment due information, the value of payment due and the maturity of the obligation. 
##      parts: [omitted] vector. the extracted cleaned text information for Item 7. 
##      table_unit: the unit of numbers in the extracted table. 
##      table_html_code: [omitted] the raw html code for the extracted table. 
##    If the table does not match: 
##      return(NULL) 
# 
## For debug: 
# # Input: 
# {
#   x = item8_notes_html$`Note 10 – Commitments and Contingencies`; 
#   tbl_html = item_tbls[[item_tbl_id]]; 
#   tbl_colname = html_text(read_html(x[loc_item[1]])); # 
#   allcurrency = TRUE; 
# }
# 
# # Output:
# {
#   tt_test <- html_to_table(tbl_html = item_tbls[[item_tbl_id]],
#                       html_text(read_html(x[loc_item[1]])), 
#                       allcurrency = TRUE )
#   tt_test$table
# }
## ========================================================================================== 

html_to_table <- function(
    tbl_html, # the HTML code for the table 
    item_html, # the HTML code for the full Item/Note/section 
    tbl_html_id = NULL, # the id for the HTML table > used when there are multiple matched tables in the `item_html`
    tbl_colname, # candidate name for the column if the column name is omitted. # e.g "000032019321000105"
    item_regex, # the regex of item of interest 
    allcurrency = TRUE # whether all numbers in the table are in the currency format. 
    # rawinfo = FALSE # whether to keep  output variable "parts" and "table_html_code" in the output. 
) {
  text_break_node_id <- read_xml(paste("<table><tr><td> &lt;footnote", tbl_html_id, "&gt; </td></tr></table>\n", sep = ""))
  
  # step 3.1. convert the table into a matrix format. 
  ### clean the table ## *updated August 22, 2023 
  item_table0 <- unique.matrix(as.matrix(html_table(tbl_html, header = F)), MARGIN = 2) %>% 
    .[,colSums(is.na(.)) != nrow(.),drop=F] # drop all NA or duplicated columns.
  item_table0 <- apply(item_table0, MARGIN = 2,
                       FUN = function(x) gsub(x = x,
                                              pattern = "\\([a-zA-Z0-9]{1}\\)",
                                              replacement = "") %>%
                         trimws) %>% 
    `dimnames<-`(value = NULL)
  
  if ( any(nchar(item_table0) > 150, na.rm = TRUE) ) {
    ## wired output: 
    # E.g. "2018/QTR2/20180402_10-K_edgar_data_1705012_0001493152-18-004457.txt" 
    return(list(table = NULL, # cbind.data.frame(tbl_numbers_cleaned, unit = item_table_unit) 
                parts = NULL,
                table_unit = NULL, 
                table_html_code = NULL
    ) ) 
  }
  
  # step 3.2. clean the rows in the table
  ## remove rows with all same elements 
  ## [deprecated] first check whether the table needs to be transposed.
  ## two steps:
  ## (1) check whether the first column matches the pattern for anticipated column names.
  ## (2) check whether the first column matches the pattern for anticipated row names.
  ## transpose the table if the first column is unusual!
  
  ## create variable `transpose_yes`:= TRUE if the row names are not for items, but for periods. 
  transpose_yes <- 
    ( any(grepl(pattern = "(?=.(due|in|after|beyond)[^[:alpha:]])*", # updated Oct 9, 2024
                x = item_table0[,1], ignore.case = TRUE, perl = TRUE)) &
        !any(grepl(pattern = item_regex, 
                   x = item_table0[,1], ignore.case = TRUE, per = TRUE)) )
  
  # if ( any(grepl(pattern = "(?=.(due|in|after|beyond)[^[:alpha:]])*", # updated Oct 9, 2024
  #                x = item_table0[,1], ignore.case = TRUE, perl = TRUE)) &
  #      !any(grepl(pattern = item_regex,
  #                 x = item_table0[,1], ignore.case = TRUE, per = TRUE)) ) {
  #   # for the case: "0001144204-17-014104" ## sum(item_table0[1,] %in% month.name) > 0
  #   ## remove columns with only $ or NA
  #   item_table0 <- # item_table0 %>%
  #     item_table0[, colSums(item_table0 == "$") == 0 & !is.na(colSums(item_table0 == "$")), drop=F]
  #   ## transpose the matrix
  #   item_table0 <- t(item_table0)
  # } 
  
  ### check and remove empty rows 
  if ( length(which(apply(item_table0, MARGIN = 1,
                          FUN = function(x) sum(str_count(na.omit(x), "[[:print:]]"), na.rm = T)) == 0)) > 0 ) {
    
    item_table2 <- item_table0[-which(apply(item_table0, MARGIN = 1,
                                            FUN = function(x) sum(nchar(x), na.rm = T)) == 0),,drop=F] # remove empty rows 
  } else {
    item_table2 <- item_table0
  } ## *updated Oct 11, 2023 
  
  # step 3.3. record the unit $ for the rows and columns with numbers 
  ## whether has `$`: ## *updated Oct 15, 2024 
  ## `$`s are used to identify headers/body and true columns. 
  item_table_dollar <- rep("", ncol(item_table2))
  item_table_dollar[which(colSums(item_table2 == "$", na.rm = T) > 0) + 1] <- "D$-" # record the column that is in dollar ($)
  if (sum(nchar(item_table_dollar)) == 0) {
    ## if no single `$` is identified in the table. ## *updated Oct 15, 2024 
    item_table_dollar[which(apply(item_table2, MARGIN = 2, FUN = function(x) any(grepl(pattern = "\\$\\d+", x = x)) ))] <- "D$-"
    ## if still no `$` identified: ## *updated Nov 5, 2024 
    if (sum(nchar(item_table_dollar)) == 0) {
      # E.g. "2018/QTR1/20180228_10-K_edgar_data_1492426_0001564590-18-003661.txt" 
      item_table_values <- grepl(pattern = "\\d,\\d", x = item_table2, perl = TRUE) %>% 
        matrix(data = ., nrow = nrow(item_table2), byrow = FALSE) 
      
      item_table_dollar[which(apply(item_table_values, MARGIN = 2, any))] <- "D$-"  ## col start
      }
  }
  
  
  ## check by each row whether the '$' exists. 
  item_table_body <- apply(item_table2, MARGIN = 1, FUN = function(x) {
    sum(grepl(pattern = "^\\$", x = x, perl = TRUE))
  }) 
  if (!any(item_table_body > 0) ) {
    item_table_body <- (apply(item_table_values, MARGIN = 1, any)) ## row start 
  }
  ## identify the starting row that contain information
  item_table_headerid <- which(item_table_body > 0)[1] ## header is before this line 
  item_table2[item_table_headerid, 1] <- paste("<FirsT>", item_table2[item_table_headerid, 1], sep = "")
  if (item_table_headerid <= 1) {
    ## if the header does not exist, I will add the column headers from input `tbl_colname`
    colid <- which(colSums(item_table2 == "$", na.rm = T) > 0)[1]
    item_table2 <- rbind(c(rep("", colid-1),
            rep(tbl_colname, ncol(item_table2)-colid+1)),
          item_table2)
    # ## and update the `item_table_header` 
    # item_table_headerid <- item_table_headerid + 1 
  } # `item_table2` is updated. 
  
  # step 3.4. finish the pre-cleaning of the table 
  ## output: variable `item_table` contains the result 
  item_table3 <- item_table2 %>% 
    rbind(item_table_dollar, ., deparse.level = 0) %>% # add the symbol ($) info in the first row 
    .[, colSums(. == "$", na.rm = T) == 0 & colSums(is.na(item_table2)) != nrow(item_table2), drop=F] %>% # remove columns having only $ or NA (past code: <!is.na(colSums(. == "$"))> )
    unique.matrix(x = ., MARGIN = 2)  # remove repeated columns 
  
  item_table <- item_table3 %>% 
    .[apply(., MARGIN = 1, FUN = function(x) length((unique(x)))) != 1,,drop=F] %>% # remove merged rows 
    .[,apply(., MARGIN = 2, FUN = function(x) sum(nchar(x, type = "width"))) != 0,drop=F] # remove zero width columns 
  
  # step 3.5. locate and extract the header row(s) in the table 
  ### the header name may be spread across several rows. 
  ### record the column ids for rownames (row-headers), ## *updated Oct 15, 2023 
  if (allcurrency == TRUE) { 
    ## if all values in the table are in the currency format. 
    item_table_colheaders <- which(cumsum(nchar(item_table[1,]) > 0) == 0)
  } else {
    ## if some values are not in the currency format. 
    item_table_headerid <- grep(pattern = "<FirsT>", x = item_table[,1], fixed = TRUE) 
    ## use brutal force to identify the starting column of the column headers. 
    item_table_colheaders <- which(
      cumsum(
        grepl(
          pattern = "pay|due|in|after|beyond|purcha", ignore.case = T, 
          x = apply(
            item_table[min(2, item_table_headerid):item_table_headerid,,drop=F], # pick all rows contain the header information 
            MARGIN = 2, FUN = function(x) paste(x, collapse = " ")
          ) 
        ) 
      )  == 0 ) 
    ## OR use the brutal force algo: check the duplication. 
    if (length(item_table_colheaders) == 0) { # e.g. "0001564590-21-004296" 
      item_table_colheaders <- which(cumsum((!duplicated(apply(item_table[min(2, item_table_headerid):item_table_headerid,,drop=F], # pick the header rows
                                                               MARGIN = 2, FUN = function(x) paste(x, collapse = " ")) ) ) ) == 1 )
    }
  } 
  
  #### replace the NA in the matrix entry
  item_table <- apply(item_table, MARGIN = 2, FUN = function(x) replace_na(x, "N/A"))
  
  #### the first column with row info ## *to update: Oct 9, 2024 ====  
  #### if multiple first column is found, combine elements in the same row and set it as the new rowname. 
  if (length(item_table_colheaders) > 1) { # if multiple first columns
    ## check the similarity between all potential first columns apart from the actual first column. 
    item_table_colheaders <- sapply(X = item_table_colheaders, FUN = function(col_id) {
      ## benchmark is the first column and the first column of the value
      bench_dist <- mean(adist(item_table[,1], item_table[,tail(item_table_colheaders,1)+1] ) )
      candid_dist <- mean(adist(item_table[,col_id],item_table[,tail(item_table_colheaders,1)+1] ) )
      # mean(adist(c(rep("", 3), item_table[-(1:3),1]), item_table[,tail(item_table_colheaders,1)+1]))
      if (candid_dist >= (bench_dist + candid_dist)/2 ) {
        return(col_id) # return the column id if it is closer to the first column. 
      } else {
        return(NA)
      }
    }, simplify = TRUE, USE.NAMES = FALSE) %>% .[!is.na(.)]
    
    item_table <- cbind(
      as.matrix(apply(
        item_table[,item_table_colheaders,drop=F], MARGIN = 1,
        FUN = function(x) paste(unique(x[nchar(x, type = "width") != 0]), collapse = " - ")
      ) ) ,  
      item_table[,-item_table_colheaders, drop=F] 
    )
  } 
  
  # step 3.6. clean and keep the rows with information in the table. 
  #### the new `period` variable and rows to be kept 
  #### [deprecated] all information will be kept at this stage, 
  ####    also the function `tbl.rowkeep2()` is specifically for repurchase tables. 
  tbl_rowkeep_info <- tbl.rowkeep2(regex_row = "\\w",
                                   row_name = item_table[,1], reporting_qrt = reporting_qrt)
  
  
  if (NA %in% tbl_rowkeep_info) { # IF THE TABLE IS NOT VALID 
    ## no actual table can be identified 
    cat("No Table Identified!")
    return(NULL) 
  } else {
    ## if a proper table is identified 
    #    ## Continue for a valid table    
    item_table_headerid <- grep(pattern = "<FirsT>", x = item_table[,1], fixed = TRUE) 
    tbl_rowkeep <- tbl_rowkeep_info$rowkeep %>% 
      .[. >= item_table_headerid] # identify the rows to be kept in `item_table`
    tbl_periods <- tbl_rowkeep_info$period %>% 
      .[tbl_rowkeep_info$rowkeep >= item_table_headerid] # return the period for each column 
    
    ### clean rows in the table and exclude the header rows. 
    tbl_numbers <- item_table %>% .[tbl_rowkeep, ,drop=F] %>% # keep the rows after|beyond the headers
      # cbind(., `length<-`(tbl_periods, nrow(.))) %>%  # add 'period' column
      .[match(tbl_rowkeep[tbl_rowkeep >= (tbl_rowkeep)[1]], tbl_rowkeep), ,drop=F] # keep the rows with values
    
    ### create the tbl_titles
    if (item_table_headerid == 1) {
      ## if column headers are in one cell each, 
      tbl_title0 <- item_table[item_table_headerid,-1,drop=T] %>%
        ## remove any number labels (e.g. (1)) 
        gsub(pattern = "\\([a-zA-Z0-9]{1}\\)", replacement = "", x = .) %>% 
        trimws %>% as.vector
    } else {
      ## if column headers are spread to multiple cells in each column, 
      ## collapse cells in each column and store the full column name. 
      tbl_title0 <- apply(item_table[1:(item_table_headerid-1),-1,drop=F], MARGIN = 2,
                          FUN = function(name) paste(name, collapse = " ") ) %>% 
        ## remove any number labels (e.g. (1)) 
        gsub(pattern = "\\([a-zA-Z0-9]{1}\\)", replacement = "", x = .) %>%
        trimws %>% as.vector
    }
    
    ### to impute missing headers 
    tbl_title0_missingid <- which(nchar(tbl_title0, type = "width") == 0) %>% 
      .[. != 1]
    if (length(tbl_title0) > 0) {
      tbl_title0[tbl_title0_missingid] <- tbl_title0[tbl_title0_missingid-1] 
    }
    tbl_title <- c("item", (tbl_title0)) ## final headers 
    
    # step 3.7. clean the columns. 
    ### store duplicated and non-duplicated column headers
    tbl_title_dupid <- cumsum(!duplicated(gsub("D\\$-|\\s", "", tbl_title)))
    
    if (max(tbl_title_dupid) < length(tbl_title)) { # if there are duplicated headers
      ## clean and remove the columns with duplicated 
      tbl_numbers <- sapply(X = 1:max(tbl_title_dupid), FUN = function(x) {
        apply(tbl_numbers[, which(tbl_title_dupid == x),drop=F], MARGIN = 1, 
              FUN = function(x) 
                paste(unique(x), collapse = " ")) %>% 
          str_replace_all(pattern = "\\$|(\\s*?)\\([12ab]\\)", replacement = "")
      })
      
      if (is.null(dim(tbl_numbers))) {
        tbl_numbers <- matrix(tbl_numbers, nrow = 1)
      }
      ## clean the wired values (id "0001039684-11-000029")
      if (sum(str_count(tbl_numbers[,1], pattern = "[a-zA-Z]") == 
              str_count(tbl_numbers[,2], pattern = "[a-zA-Z]")) > nrow(tbl_numbers)/2 ) {
        tbl_numbers[,c(-1, -ncol(tbl_numbers))] <- apply(tbl_numbers[,c(-1, -ncol(tbl_numbers)), drop=F],
                                                         MARGIN = 2,
                                                         FUN = function(x) str_replace_all(string = x,
                                                                                           pattern = paste(gsub(pattern = "<FirsT>", replacement = "", tbl_numbers[,1]), collapse = "|"), replacement = ""))
      }
      
    } ## otherwise just use the old tbl_numbers 
    
    #### append back the column headers ## *updated Oct 15, 2024 
    colnames(tbl_numbers) <- sapply(X = unique(tbl_title_dupid), FUN = function(id) {
      candid_titlename <- tbl_title[tbl_title_dupid == id] 
      output_titlename <- candid_titlename[which.max(nchar(candid_titlename))]
      return(output_titlename)
    }, simplify = TRUE, USE.NAMES = TRUE) 
    
    
    # step 3.8. convert table from wide to long. 
    ### return the cleaned table - from wide to long
    tbl_numbers_cleaned <- melt(as.data.frame(tbl_numbers), id.vars = c("item")) %>% 
      mutate(item = gsub(pattern = "<FirsT>", replacement = "", x = item) ) %>%  # clean the name 
      filter(!grepl(pattern = "^V\\d+$", x = variable, ignore.case = FALSE))
    if (transpose_yes == TRUE) {
      # if the table needs to be transposed. 
      colnames(tbl_numbers_cleaned) <- c("variable", "item", "value") 
    } 
    
    # tbl_numbers_cleaned_y <- tbl_numbers_cleaned %>% 
    #   select(variable) %>% 
    #   unique() %>% 
    #   mutate(period = str_extract_all(string = variable, pattern = "(?i)\\d+(\\.\\d+)?|after|beyond|later") ) %>% 
    #   unnest(cols = period) %>% 
    #   mutate(period = as.integer(str_replace(string = period, pattern = "(?i)after|beyond|later", replacement = "2050"))) %>% 
    #   group_by(variable) %>% 
    #   summarise(rank = mean(period) ) %>% 
    #   ungroup() %>% 
    #   mutate(rank = rank(rank))
    # 
    # tbl_numbers_cleaned <- tbl_numbers_cleaned[, c("item", "variable", "value")] %>%  
    #   as_tibble() %>% 
    #   left_join(## `y` here ranks the sequence of each item, from less than 1 year to more than e.g. 5 years. 
    #             tbl_numbers_cleaned_y, 
    #             by = join_by("variable" == "variable") 
    #   ) 
    
    tbl_numbers_cleaned <- tbl_numbers_cleaned[, c("item", "variable", "value")] %>%
      left_join(x = .,
                ## `y` here ranks the sequence of each item, from less than 1 year to more than e.g. 5 years.
                y = select(., variable) %>%
                  unique() %>%
                  mutate(period = str_extract_all(string = variable, pattern = "(?i)\\d+(\\.\\d+)?|after|beyond|later") ) %>%
                  unnest(cols = period) %>%
                  mutate(period = as.integer(str_replace(string = period, pattern = "(?i)after|beyond|later", replacement = "2050"))) %>%
                  group_by(variable) %>%
                  summarise(rank = mean(period) ) %>%
                  ungroup() %>%
                  mutate(rank = rank(rank)),
                by = "variable"
      )
    
    # step 3.9. extract the unit information for numbers in the table. 
    ## <table unit information>
    ## extract the unit information from the table ## updated July 16, 2023
    item_table_unit <- str_extract(string = html_text(tbl_html, trim = T),
                                   pattern = "\\((I|i)(N|n)\\s*[^()0-9c][^()0-9]+\\)")
    if (is.na(item_table_unit)) { 
      # check directly in the table if the `item_table_unit` returns NA 
      item_table_unit <- grep(pattern = "in\\s*(hundred|thousand|million|billion)",
                              x = item_table0, ignore.case = T, value = T)[1]
    } 
    
    ## <text info excl. table> ## *updated August 22, 2023 (issues)
    ## extract item text and exclude the table. ## *updated August 22, 2023 
    table_html_code <- as.character(tbl_html) # store the raw html code for the table 
    xml_replace(.x = tbl_html, .value = text_break_node_id) # replace the identified table
    filing_item2_txt <- as.character(item_html) %>%
      clean_html(input_string = ., 
                 pattern = c("(</\\w+\\s*>\\s*)<([^/>]+>\\s*<[^/>]+>)",
                             "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])") ) %>%  
      apply(MARGIN = 2, FUN = function(x) {
        res <- try(text <- html_text(read_html(x), trim = TRUE), silent = TRUE)
        
        if ((inherits(res, "try-error"))) {
          return("")
        } 
        return(text)
      } ) %>% 
      as.vector() %>% 
      .[. != ""] # store the txt excl. table
    
    if (is.na(item_table_unit)) { 
      ## if still no unit info inside the table
      ## identify the location of the table (`item_table_loc`) in the text. 
      item_table_loc <- grep(pattern = html_text(x = text_break_node_id, trim = TRUE),
                             x = filing_item2_txt, fixed = TRUE) %>% 
        tail(1)
      # cat(paste(item_table_loc, collapse = ", ")) # for debug
      # cat("\n")
      ## search in the text before the table 
      item_table_unit <- str_extract_all(string = filing_item2_txt[1:(item_table_loc - 1)],
                                         pattern = "\\([^()]*(I|i)(N|n)\\s*(hundred|thousand|million|billion)[^()]*\\)", 
                                         # pattern = "\\((I|i)(N|n)\\s*[^()0-9c][^()0-9]+\\)",
                                         simplify = T) %>% 
        as.vector() %>% 
        .[. != ""] %>% 
        tail(1) 
    }
    
    ## print("k2") 
    return(list(table = as.matrix(tbl_numbers_cleaned), # cbind.data.frame(tbl_numbers_cleaned, unit = item_table_unit) 
                parts = filing_item2_txt,
                table_unit = item_table_unit, 
                table_html_code = table_html_code
    ) ) 
    
  }
  
}

