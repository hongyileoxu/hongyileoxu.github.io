# function: html_to_structure(): ---- 
# For a given raw html code object, get the structure of the html file: 
#
## Arg: 
##    item_html: character/xml_document: the raw HTML file. 
##          If the input is a vector, it will be collapsed into one character. 
##    headerlength: integer: a vector of integers for the minimum and maximum length of the header(s). default = c(0, 8)
##
## Output: 
##    text: character: a vector of cleaned text extracted from the HTML. 
##    headerid: integer: a vector of integers for the location of headers in the HTML. 
##          Combine `text[headerid]`, we can obtain the name of headers in the given HTML. i.e. the ToC for the given HTML. 
##          
# 

html_to_structure <- function(item_html, # a character the raw HTML file 
                              headerlength = c(1, 8) # the (min, max) number of characters in the header
                              ) {
  ### step 3B-1: get the cleaned text in blocks. 
  #### clean raw html blocks. 
  filing_item7_rawhtml <- as.character(item_html) %>% 
      ifelse(length(.) == 1, ., paste(., collapse = "")) %>% # check and collapse into one character. 
    clean_html2(input_string = .) %>% 
    as.vector()
  #### extract the text from the html blocks. 
  filing_item7_txt <- filing_item7_rawhtml %>%  
    sapply(X = ., FUN = function(x) {
      res <- try(output <- html_text(read_html(x), trim = TRUE), silent = T) 
      ## if e.g. `x = "</div></div>"`
      if (inherits(res, "try-error")) { output <- "" } 
      return(output) 
    }, simplify = TRUE, USE.NAMES = FALSE) %>% 
    as.vector() # %>% # store the txt excl. table
  # .[. != ""] # remove empty elements in the vector
  
  ### step 3B-2: identify the subsection headers. 
  #### count the number of words in each block and identify the block as the sub-item header. 
  filing_item7_txtcount <- filing_item7_txt %>% 
    str_count(string = ., pattern = "[a-zA-Z]+")
  filing_item7_txtcount[grepl(pattern = "^(\\W)*[a-z]|(\\|)|^[0-9\\s]+$|([Tt]able [Oo]f)|[;$:,]", x = filing_item7_txt) |
                          (filing_item7_txtcount == 0)] <- -1 # exclude strings with (1) "|", (2) not starting with capital letter or (3) no text count. 
  filing_item7_headerid <- which(filing_item7_txtcount <= headerlength[2] &
                                   filing_item7_txtcount >= headerlength[1]) # the row id (relative to `filing_item7_txt`) for potential headers, including sub-headers. 
  # filing_item7_txt[filing_item7_headerid] # view the extracted sub-item/subsection headers. 
  
  return(list(text = filing_item7_txt, # a vector of raw text extracted from the HTML. 
              headerid = filing_item7_headerid # the location of headers from the HTML. 
              ))
}