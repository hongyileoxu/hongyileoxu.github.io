# # =========================================================================
# # This file stores functions used to clean the SEC data files 
# # Working Directory: ~/BeckerJosephsonXu_2025/Collect_Parse_10Ks/
# # Date created: September 18, 2024 
# # Date updated: Oct 13, 2024 
# # Operating: Rstudio Sever - NHH  
# # Previous File: `BJX_project.qmd` > 
# # Next File: > ``
# # ========================================================================= 
# 
# # # default inputs ---- 
# # # Create a named vector for conversion
# # num_map <- c("zero" = 0, "one" = 1, "two" = 2, "three" = 3, 
# #              "four" = 4, "five" = 5, "six" = 6, 
# #              "seven" = 7, "eight" = 8, "nine" = 9) 
# # 
# # largeunits_regex <- "thousand|milli|bill|tril" # regex to identify the number units. 
# # 
# # # a. googledrive_download(): generate cmd code to download Google Drive files ----
# # # 
# # ## Arg: 
# # ##    api_key: API key generated from Oauth 2.0 Playground by Google. 
# # ##    file_info: a n-by-2 data.frame with sharing id in the first column and file name in the second column. 
# # ##    file_link: the sharing id of the file on Google Drive. 
# # ##    file_name: the name given to the downloaded file. 
# # ##    to: the path for the downloaded files. 
# # ## Output: 
# # ##    cmd_output: curl commands to download file(s). 
# # 
# # googledrive_download <- function(api_key, file_info, file_link, file_name, to = "/scratch/nhh/sec/") {
# #   if (missing(file_info)) { 
# #     # if argument `file_info` is not provided 
# #     cmd_output <- paste('curl -H "Authorization: Bearer ', api_key, '" ', "https://www.googleapis.com/drive/v3/files/", file_link, "?alt=media -o ", to, file_name, "   ", sep = "") 
# #   } else {
# #     # if argument `file_info` is provided 
# #     if (is.data.frame(file_info) & dim(file_info)[2] == 2) {
# #       cmd_output <- paste(apply(X = file_info, MARGIN = 1, FUN = function(x) paste('curl -H "Authorization: Bearer ', api_key, '" ', "https://www.googleapis.com/drive/v3/files/", x[1], "?alt=media -o ", to, x[2], sep = "") ), collapse = ";  " )
# #     } else {
# #       stop("Error: 'file_info' parameter is not data.frame object or has more than 2 columns.")
# #     }
# #   }
# #   return(cmd_output)
# # } 
# # 
# # 
# # # b. sec_filing_nameinfo(): extract information from the file path ---- 
# # # 
# # ## Arg: 
# # ##    file_path: the full path name of files in the zip files. 
# # ##    keep.original: whether keep the original full file path. TRUE is yes and FALSE is no. 
# # ## Output: 
# # ##    path_info: a n-by-5 matrix storing the information about qtr_calender, filing_date, file_type, CIK, accession_num in each column. 
# # 
# # sec_filing_nameinfo <- function(file_path, keep.original = TRUE) {
# #   path_cleaned <- str_extract(string = file_path, pattern = "QTR\\d/.*")
# #   path_info <- str_split(string = path_cleaned, pattern = "/|(_edgar_data_|_)", simplify = TRUE) %>% 
# #     `colnames<-`(value = c("qtr_calender", "filing_date", "file_type", "CIK", "accession_num"))
# #   if (isTRUE(keep.original)) {
# #     # if the full path is kept in the output
# #     path_info <- cbind(path_info, full_path = file_path)
# #   }
# #   return(path_info)
# # }
# # 
# # 
# # # c. clean_html(): clean the raw files and ensure contents in one tag not be broken into several parts ---- 
# # # *updated Oct 10, 2024 
# # # 
# # ## Arg: 
# # ##    input_string: one string with contents from `readLines()`. 
# # ##    pattern: the regular expression used to match closing tags (</...>)
# # ##      -: [ ]"</[a-zA-Z]+>\\s*</[a-zA-Z]+>\\s*<[^/]"
# # ##      -: [ ]"(<\\/[a-zA-Z]+>\\s*<\\/[a-zA-Z]+>\\s*)<([^/])" 
# # ##      -: [!] "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])" # the one used in this task 
# # ## Output: 
# # ##    result: the cleaned vector of strings. 
# # 
# # clean_html <- function(input_string, pattern = "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])") {
# #   # Split the string but keep the closing tags in the result
# #   string_main <- unlist(strsplit(input_string, pattern, perl = TRUE))
# #   
# #   # Append the matched closing tags back into the result
# #   matches <- regmatches(input_string, gregexpr(pattern, input_string)) 
# #   
# #   # Modify the tags 
# #   string_tag <- lapply(X = matches, FUN = function(x) gsub(pattern = pattern, replacement = "\\1~B~<\\2", x) )
# #   
# #   # Combine the split strings and tags and re-split the string 
# #   result <- paste(c(rbind(string_main, c(unlist(string_tag), ""))), collapse = "") %>%
# #     str_split(pattern = "~B~", simplify = T)
# #   
# #   return(result)
# # }
# # 
# # # c2. clean_html2(): clean the raw files and isolating <table> in the raw html text ---- 
# # 
# # clean_html2 <- function(input_string, pattern = "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])") {
# #   # first isolate the contents in the <table>...</table> 
# #   input_components <- input_string %>% 
# #     gsub("<(table|TABLE|Table)", "~TB~<\\1", x = .) %>% 
# #     gsub("</(table|TABLE|Table)>", "</\\1>~TB~", x = .) %>% 
# #     strsplit(x = ., split = "~TB~", fixed = T) %>%
# #     unlist() 
# #   
# #   # for each component without <table>, apply the function clean_html()
# #   result <- sapply(X = input_components, FUN = function(x) {
# #     if (!grepl(pattern = "<(table|TABLE|Table)", x)) {
# #       ## if x is not a table
# #       output <- as.vector(clean_html(x, pattern = pattern))
# #       output[grep(pattern = "<[^/]", x = output, invert = T)] <- "<p></p>"
# #     } else {
# #       ## return the raw text for the table
# #       output <- x  # Corrected 'ouptut' to 'output'
# #     }
# #     return(output)
# #   }, USE.NAMES = FALSE) %>% unlist()
# #   
# #   
# #   return(result)
# # }
# # 
# # # filing_toc <- filing.toc(x = filing, regex_toc = "<text>|</text>") 
# # # # browsable(HTML(as.character(filing_toc))) # view the ToC in html format 
# # # 
# # # html_nodes(filing.toc(x = filing), "table")[2] %>% 
# # #   grep("(?=.*item)(?=.*href)", x = ., perl = TRUE, ignore.case = TRUE, value = FALSE)
# # # 
# # # html_nodes(filing.toc(x = filing), "table")[2] %>% 
# # #   grep("(?=.*page)(?=.*href)", x = ., perl = TRUE, ignore.case = TRUE, value = FALSE)
# # # 
# # # 
# # # toc_tbl <- html_nodes(filing.toc(x = filing), "table") %>% # tables including the toc 
# # #   # .[grep("(?=.*\\bpage\\b)(?=.*\\bhref\\b)", x = ., ignore.case = T, perl = T)] 
# # #   .[ intersect(grep("page", x = ., ignore.case = T), grep("href", x = ., ignore.case = T) ) ]
# # # html_text(toc_tbl[1])
# #      
# 
# # d. loc.item_MDnA(): locate the item of interest: MD&A ---- 
# # copied from SEC_web_v3cfunctions.R: (https://github.com/hongyileoxu/hongyileoxu.github.io/blob/main/research/RepurchaseProject/SEC_web_v3cfunctions.R)
# # Return the location of the item of interest in the raw file specified in `x`. 
# # 
# ## Arg: 
# ##    x: the text file in characters. 
# ##    filing_type: choose the type of filings. 10-K or 10-Q. 
# ##    regex_item: character: the regex for the item of interest in the table of contents. 
# ##    regex_num: character: the regex for the item number of interest in the table of contens. 
# ## Output: list(loc_item = loc_item, item_id = item_id, item = c(regex1, regex2))
# ##    loc_item: the location of the item with the starting and ending index. 
# ##    item_id: the link href for the item. 
# ##    item: the regex for the identified item. 
# #     
# ## particularly item 7 and item 7A: MD&A and others 
# loc.item_MDnA  <- function(x, # filing in raw data 
#                            filing_type = "10-K", # filing type from the previous input
#                            regex_item = c(NA, "(?=.*management)(?=.*discussion)(?=.*analysis)(?=.*operation)"), # item header 
#                            regex_num = c("[>](Item|ITEM)[^0-9]+2\\.", "[>](Item|ITEM)[^0-9]+7\\."), # item number 
#                            regex_perl = TRUE 
# ) { 
#   # locate the section of the item of interest 
#   ## > item 2 in 10-Q: "Unregistered Sales of Equity Securities and Use of Proceeds" ;
#   ## > item 5 in 10-K: "Market for Registrant&rsquo;s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities" ;
#   ## > item 7 in 10-K: "MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS""
#   
#   regex1 <- regex_item[filing_type == c("10-Q", "10-K")] # identify the regex 
#   regex2 <- regex_num[filing_type == c("10-Q", "10-K")] # identify the regex for item
#   
#   ## <Find item_id in the ToC> ## updated Oct 8, 2024 
#   toc_tbl <- html_nodes(filing.toc(x = x), "table") %>% # tables including the toc 
#     .[grepl(pattern = "item", x = ., ignore.case = T) & grepl(pattern = "href", x = ., ignore.case = T)]
#   ### if multiple ToCs are selected: 
#   if (any(grepl(pattern = ">Part.+I", x = toc_tbl, ignore.case = T))) {
#     toc_tbl_id <- which(grepl(pattern = regex1, x = toc_tbl, ignore.case = T, perl = regex_perl) )[1] # locate the table for TOC: will return NA if there are no tables in toc_tbl
#   } else {
#     toc_tbl_id <- which(grepl(pattern = "SIGNATURE|EXHIBIT", x = toc_tbl, ignore.case = T))[1] # locate the table for TOC: will return NA if there are no tables in toc_tbl
#   }
#   
#   # if such table exists & contains url 
#   if (isTRUE(grepl(pattern = "href", x = toc_tbl[[toc_tbl_id]], ignore.case = T))) { 
#     ## find the row of item in the TOC
#     toc_row <- html_nodes(toc_tbl[[toc_tbl_id]], "tr") %>% # separate each row
#       .[grep(pattern = "^(Item|ITEM|\\d)", x = html_text(., trim = T), ignore.case = T)]
#     toc_row_id <- grep(pattern = regex1, x = html_text(toc_row), ignore.case = T, perl = regex_perl)[1] # separate and identify the row
#     
#     ## find the id for the item  ## updated July 16, 2023
#     if (!is.na(toc_row_id)) { # if this item exists in the toc 
#       item_id1 <- grep("#.+", html_attr(html_nodes(toc_row[toc_row_id], "a"), "href"), value = T)[1]
#       if (!grepl('#', item_id1)) {
#         # if such id does not exist > 
#         item_id <- rep(NA, 2)
#       } else {
#         ### search for the id for the next item. ## udpated Sept 23, 2024 
#         ### check whether the ToC has multiple components ## updated July 16, 2023 
#         ### In some cases, one ToC is broken into multiple <table>...</table>s. 
#         if (toc_row_id == length(toc_row)) {
#           #### re-find all tables for the ToC
#           toc_tbl_ids <- which(grepl(pattern = ">Part.+I|SIGNATURE", x = toc_tbl, ignore.case = T) )
#           #### combine all tables into one and re-search for the item of interest 
#           #### record all id(s) in the ToC ## updated July 16, 2023 
#           toc_row_all <- html_nodes(toc_tbl[toc_tbl_ids], "tr") %>% # separate each row
#             .[grep(pattern = "^(Item|ITEM|\\d)|(Exhibit|SIGNATURE)", x = html_text(., trim = T), ignore.case = T)]
#           item_id_all <- unique(grep("#", html_attr(html_nodes(toc_row_all, "a"), "href"), value = T)) 
#           #### location the id for the next item 
#           item_id2 <- item_id_all[match(item_id1, item_id_all)+1] 
#         } else {
#           #### otherwise, only one <table> for the ToC. 
#           #### extract the id from the next "href" item. 
#           item_id2 <- grep("#.+", html_attr(html_nodes(toc_row[toc_row_id+1], "a"), "href"), value = T)[1]
#           if (!grepl('#', item_id2)) { 
#             # check whether it is a valid "href" 
#             # -> if not then replace with the next valid one 
#             item_id2 <- grep('#.+', html_attr(html_nodes(toc_row[-(1:toc_row_id)], "a"), "href"), value = T)[1] ## updated July 16, 2023 
#           }
#           
#         } ## updated July 16, 2023  
#         
#         if (item_id1 == item_id2 & !is.na(item_id2)) { 
#           # for some wired errors for instance: <https://www.sec.gov/Archives/edgar/data/858655/000155837017000308/hayn-20161231x10q.htm#Toc>
#           item_id1 <- grep("#.+", html_attr(html_nodes(toc_row[toc_row_id], "a"), "href"), value = T)[2]
#         }
#         
#         item_id <-  sub(pattern = '#', replacement = '', x = c(item_id1, item_id2))
#         
#         ## add a backup id ## updated August 8, 2023 
#         item_id_backup <- grep('#.+', html_attr(html_nodes(toc_row[-(1:(toc_row_id))], "a"), "href"), value = T)[2:3] %>% ## updated August 8, 2023 
#           sub(pattern = '#', replacement = '', x = .) 
#       }
#     } else { 
#       # if a valid `toc_row_id` cannot be found. 
#       item_id <- rep(NA, 2)
#     }
#   } else {
#     item_id <- rep(NA, 2)
#   }
#   
#   ## <What if an url is found.>  
#   if ( ifelse(any(is.na(item_id)), FALSE, item_id[1] != item_id[2]) ) { 
#     # locate the item if item_id (url) is found ## updated July 15, 2023 ----
#     
#     if (any(nchar(item_id) >= 3)) {
#       ## if the id is in the acceptable length
#       loc_item <- vapply(X = item_id,
#                          FUN = function(p) {
#                            loc_item0 <- grep(pattern = paste("[<].+=(\"|\')", gsub("\\W", "\\\\\\W", p), "(\"|\')", sep = "")[1], x = x)
#                            return(ifelse(length(loc_item0) != 1, loc_item0[2], loc_item0[1]))
#                          },
#                          FUN.VALUE = numeric(1))
#     } else {
#       ## if only the num of characters is too few in the id 
#       x_text_id <- grep(pattern = '<text>|</text>', x = x, ignore.case = T)[1:2] # identify the main body 
#       ## extract all attributes in each part of the text  
#       x_text_attr <- lapply(x_text_id[1]:x_text_id[2], FUN = function(id) {
#         res_attr <- try(html_attrs(html_nodes(read_html(x[id]), "a")), silent = T)
#         ifelse(inherits(res_attr, "try-error"), output <- NA,
#                ifelse(is.null(unlist(res_attr)[1]), output <- NA, output <- unlist(res_attr)) )
#         return(output)
#       } )
#       ## find the paragraph containing matched id(s) 
#       loc_item <- sapply(item_id, 
#                          FUN = function(id) {
#                            which(sapply(x_text_attr, 
#                                         FUN = function(x) any(grepl(pattern = paste("^", id, "$", sep = "")[1], x))))[1]
#                          } 
#                          ) + x_text_id[1] - 1
#     }
#     
#     ## if the issue has not been resolved. 
#     ## if they are wrongly directed to the same element in `filing / x`. > searching with brutal force: 
#     if ( ifelse(any(is.na(loc_item)), TRUE, diff(loc_item) <= 0 & nchar(x[loc_item[1]]) < 5000) ) { ## updated July 15, 2023 ----
#       
#       ## this part is exactly the same as the following part > brutal force
#       x_text <- sapply(X = x, FUN = function(x) {
#         res <- try(output <- html_text(read_html(x), trim = TRUE), silent = T) 
#         ## if e.g. `x = "</div></div>"`
#         if (inherits(res, "try-error")) { output <- "" } 
#         return(output) 
#       }, simplify = TRUE, USE.NAMES = FALSE) 
#       
#       ## look for all the items 
#       loc_item1 <- tail(grep(pattern = regex1, # paste("(", regex1, "|", regex2, ")", sep = "")[1],
#                              x = x_text, ignore.case = TRUE, perl = TRUE), 1)  # find the last match, as it is more likely to be the item title. 
#       # loc_item1_check <- tail(grep(pattern = ">Part.+\\bII\\b", x = x, ignore.case = T), 1) # record the Part II section in the filing
#       ## check whether the 1st location is found
#       if (length(loc_item1) > 0 ) { # if the first is identified # & length(loc_item1_check) > 0
#         # if (loc_item1 >= loc_item1_check) { # if the place is correct 
#         loc_item2 <- grep(pattern = "(>)?(Item|ITEM)[^0-9]+\\d{1}[A-Z]?[.]",
#                           x = x[(loc_item1+1):grep(pattern = '<text>|</text>', x = x, ignore.case = T)[2]],
#                           ignore.case = T, perl = regex_perl)[1] + loc_item1 # absorb the case without '>'. 
#         
#         if (is.na(loc_item2)) { # if it returns NA
#           loc_item2 <- grep(pattern = "(>)?(Item|ITEM)",
#                             x = x[(loc_item1+1):grep(pattern = '<text>|</text>', x = x, ignore.case = T)[2]],
#                             ignore.case = F, perl = regex_perl)[1] + loc_item1 # absorb the case without '>'. 
#         } ## have a second try if `loc_item2` is NA. 
#         ifelse(is.na(loc_item2), loc_item <- rep(loc_item1, 2), loc_item <- c(loc_item1, loc_item2))
#         
#         # } else {
#         #   loc_item <- rep(NA, 2)
#         # }
#       } else { # if the first is not identified
#         loc_item <- rep(NA, 2)
#       }
#     }
#     
#     
#   } else { # if no url or link/identifier is found 
#     ## look for all the items 
#     loc_item1 <- tail(grep(pattern = regex1, # paste("(", regex1, "|", regex2, ")", sep = "")[1],
#                            x = x, ignore.case = TRUE, perl = regex_perl), 1)  # find the match
#     # loc_item1_check <- tail(grep(pattern = ">Part.+\\bII\\b", x = x, ignore.case = T), 1) # record the Part II section in the filing
#     ## check whether the 1st location is found
#     if (length(loc_item1) > 0 ) { # if the first is identified # & length(loc_item1_check) > 0 ## updated July 16, 2023
#       if (loc_item1 == length(x)) {
#         loc_item <- rep(loc_item1, 2)
#       } else {
#         # if (loc_item1 >= loc_item1_check) { # if the place is correct 
#         loc_item2 <- grep(pattern = "(>)?(Item|ITEM)[^0-9]+\\d{1}[A-Z]?[.]",
#                           x = x[(loc_item1+1):grep(pattern = '<text>|</text>', x = x, ignore.case = T)[2]],
#                           ignore.case = T, perl = regex_perl)[1] + loc_item1 # absorb the case without '>'.  
#         
#         if (is.na(loc_item2)) { # if it returns NA
#           loc_item2 <- grep(pattern = "(>)?(Item|ITEM)",
#                             x = x[(loc_item1+1):grep(pattern = '<text>|</text>', x = x, ignore.case = T)[2]],
#                             ignore.case = F, perl = regex_perl)[1] + loc_item1 # absorb the case without '>'. 
#         }
#         
#         ## have a second try if `loc_item2` is NA. 
#         ifelse(is.na(loc_item2), loc_item <- rep(loc_item1, 2), loc_item <- c(loc_item1, loc_item2))
#       } 
#       
#     } else { # if the first is not identified
#       loc_item <- rep(NA, 2)
#     }
#   }
#   
#   ## return the location, id, and item number (i.e. item 2 or 5)
#   return(list(loc_item = loc_item, item_id = item_id, item = c(regex1, regex2)))
# }
# 
# # e. filing_item7_extract(): extract sentences in item 7 ---- 
# ## Arg: 
# ##    filing_txt: all txt in the item 7. 
# ##    filing_headerid: a vector of locations of all headers in item 7. 
# ##    item_regex: the regex to identify the matched text in item 7. 
# ##
# ## Output: 
# ##    output_txt: list. the extracted sentences under each sub-item if they are matched to the `item_regex`, and return NULL if no match is found. 
# # 
# # 
# # {
# #   filing_txt = note_rawtxt
# #   filing_headerid = subnote_headerid
# #   item_regex = item_regex
# # }
# 
# filing_item7_extract <- function(filing_txt, filing_headerid,
#                                  item_regex = "(?=.*purchas)(?=.*(obligation|commitment|agreement|order|contract))") {
#   ### identify the locate the relevant text 
#   filing_txt_matched <- grep(pattern = item_regex, x = filing_txt,
#                              ignore.case = TRUE, perl = TRUE, value = F)
#   
#   if (length(filing_txt_matched) == 0) {
#     ## if `filing_txt_matched` is empty
#     output_txt <- NULL
#   } else {
#     ## if `filing_txt_matched` is not empty
#     ### identify the sub-item of each relevant text 
#     ### Cut the vector into groups based on breaks
#     group_labels <- cut(filing_txt_matched, c(filing_headerid, length(filing_txt)), include.lowest = TRUE, right = FALSE)
#     ### Split the vector based on the group labels
#     split_numbers <- split(filing_txt_matched, group_labels, drop = TRUE)
#     names(split_numbers) <- filing_txt[as.integer(gsub(pattern = "\\[([0-9]{1,2}),.*", replacement = "\\1", x = names(split_numbers)))]
#     
#     output_txt <- sapply(X = split_numbers, FUN = function(x) {
#       ### extract and split the contents into sentences. 
#       filing_sentences <- str_squish(unlist(strsplit(x = filing_txt[x], split = "(?<!\\d)(?<=\\.)\\s+", perl=TRUE))) 
#       ### extract the sentences include the item numbers. 
#       filing_sentences_items <- grep(pattern = "\\d+", # "|notes?[[:blank:]]*\\b\\d{1,2}" > this is redundant. 
#                                      x = filing_sentences, ignore.case = TRUE, value = TRUE) 
#       # if (length(filing_sentences_items) == 0) {filing_sentences_items <- NULL} 
#       # return(filing_sentences_items) 
#     }) %>% Filter(function(x) length(x) > 0, .) 
#     
#     if (length(output_txt) == 0) { output_txt <- NULL }
#   } 
#   return(output_txt)
# } 
# 
# # f. vectors_to_matrix(): combine vectors with different length into one matrix with each row for one vector ---- 
# ## Arg: 
# ##    vec_list: list: a list of vectors with the same or different lengths. 
# ##    
# ## Output: 
# ##    matrix_combined: matrix: a combined matrix with padding NA for short vectors. 
# # 
# 
# vectors_to_matrix <- function(vec_list) {
#   # Find the maximum length of the vectors in the list
#   max_length <- max(sapply(vec_list, length))
#   
#   # Use sapply to extend each vector to the maximum length by padding with NA
#   matrix_combined <- sapply(vec_list, function(x) {
#     length(x) <- max_length  # Pad with NA
#     return(x)
#   }, simplify = FALSE) %>% 
#     do.call(what = rbind, args = .)
#   
#   return(matrix_combined)
# }
# 
# # g. text_to_table(): convert the text information into a table ---- 
# ## write a new function to convert numbers in the text into a matrix output. 
# ## Arg: 
# ##    text: vector: a word vector containing information to be converted. The whole word vector maps into one sentence. 
# ##    var_name: character: the name of the item of interest. 
# ##    largeunits_regex: character: regex for normally used units for large numbers. 
# ##    
# ## Output: 
# ##    output: conditional on whether we can extract two dollar values from the text 
# ##      data.frame: if yes, return a n-by-4 matrix with each column for item (name of the item), variable (time span), value (dollar value), unit (e.g. million/billion)
# ##      character: if no, return "Too many numbers" if more than two dollar values are found & return "Too few numbers" if less than two is found. 
# # 
# 
# text_to_table <- function(text,
#                           var_name, 
#                           largeunits_regex = "thousand|milli|bill|tril") {
#   ## identify the location of dollar values in the word vector. 
#   numbersid <- grep(pattern = "[$€£¥₹]", x = text, perl = TRUE)
#   # if only the two values exist: 
#   if (length(numbersid) == 2) {
#     # locate the location of the large number units
#     unitsid <- grep(pattern = largeunits_regex, x = text, ignore.case = TRUE) 
#     # full set of information on numbers + units 
#     allnumbers_id <- sort(c(numbersid, unitsid)) 
#     # locate the item separator ",": keep only the "," separating the numbers. 
#     ## "," in strings e.g. "Sept 20, 2024" are excluded. 
#     separatorid <- grep(pattern = ",", x = text, fixed = TRUE) %>% 
#       .[. > min(allnumbers_id) & . < max(allnumbers_id) ] %>% 
#       ## if such separator does not exist, manually create a separator location. 
#       ifelse(length(.)==0, yes = floor((max(unitsid) + min(numbersid) )/2 ), no = .)
#     
#     # split the word vector into two components 
#     item1 <- text[allnumbers_id[allnumbers_id <= separatorid]]
#     item2 <- text[allnumbers_id[allnumbers_id > separatorid]]
#     
#     # create the output table
#     output <- rbind.data.frame(item1, item2) %>% 
#       `colnames<-`(value = c("value", "unit") ) %>% 
#       cbind.data.frame(item = var_name, variable = c("Total", "next 12 months"), .) 
#     
#   } else {
#     # if values are not found. > a different function will be used to identify the "Note \\d{1,2}"
#     output <- ifelse(length(numbersid) > 2, 
#                      yes = paste("!Too many numbers:", length(numbersid), sep = " "), 
#                      no = paste("!Too few numbers:", length(numbersid), sep = " ") )
#   }
#   
#   return(output) 
# }
# 
# # h. filing.item(): extract text (header and/or footnote), unit and cleaned table ---- 
# # copied from SEC_web_v3cfunctions.R: (https://github.com/hongyileoxu/hongyileoxu.github.io/blob/main/research/RepurchaseProject/SEC_web_v3cfunctions.R)
# # extract the information/contents in the text
# # 
# ## Arg: 
# ##    x: the text file in characters. Use the `filing_structured` rather than the `filing`. 
# ##    loc_item: the location of the item of interest and should be a vector containing two numerical values. 
# ##    item_id: the identifer from 'href' for the item of interest and should be a vector containing two series of strings. 
# ##    item: the regex for the item of interest and should be a vector containing the regex for the item name and the item number. 
# ##    item_id_backup: a backup id. 
# ##  *above four inputs are generated from function `loc.item()` or `loc.item7()` 
# ##    reporting_qrt: the reporting quarter of the filing. 
# ##    text_break_node: the XML to replace the identified table. 
# ##    table: logical. If TRUE, the table is scrapped. 
# ##    parts: indicate the parts of information that you want 
# ##
# ## Output: 
# ##    loc_item: 
# #     
# 
# filing.item <- function(x, # filing
#                         loc_item, # the location of the item of interest
#                         item_id, # the identifier from 'href' for the section 
#                         item, # the regex for the item (item number./ item name)
#                         item_id_backup, # a backup id ## *August 8, 2023 
#                         reporting_qrt, # the quarter the filing was made 
#                         text_break_node, # the xml to replace the identified table
#                         table = TRUE, # whether to scrap the table numbers 
#                         parts = c("footnote") # the parts of information that you want 
# ) { 
#   # ! `loc_item` cannot be NA. 
#   # extract raw text from the section/item 
#   if (loc_item[1] == loc_item[2]) {
#     # if the loc_item is the same. 
#     # print("same loc_item")
#     if (any(is.na(item_id)) == TRUE) {
#       # print("no item_id")
#       item_parse <- sub(pattern = paste(".*", item[1], sep = "")[1], "", x[loc_item[1]], ignore.case = F, perl = TRUE)
#       item_txt <- sub(pattern = "(>|)(Item|ITEM|Signature|SIGNATURE).*", "", item_parse) ## *updated August 18, 2023 
#     } else {
#       
#       if (any(nchar(item_id) >= 3)) { # the id is long enough
#         # print("Yes! item_id")
#         item_parse <- sub(pattern = paste(".*(\"|\'|[^#])", item_id[1], "(\"|\'|)", sep = "")[1], "", x[loc_item[1]])
#         
#         ## check if the item_parse contains the correct item info 
#         if (grepl(paste(item[1], "|(Item|ITEM).+[36]{1}(.)?.+[A-Z]\\w+\\s+[A-Z]", sep = ""), substr(html_text(read_html(item_parse)), 1, 1500), ignore.case = F)) { ## July 15, 2023
#           if (grepl(pattern = paste("(\"|\'|[^#])", item_id[2], "(\"|\'|)", sep=""), x = item_parse) ) {
#             item_txt <- sub(pattern = paste("(\"|\'|[^#])", item_id[2], "(\"|\'|)", ".*", sep=""), "", item_parse)
#           } else { ## *August 8, 2023 
#             item_txt <- sub(pattern = "(>|)(Item|ITEM)\\s*[678].*", "", item_parse) ## August 29, 2023 
#           }
#           
#         } else { # if not, then use brutal force to search for ">Item 2." or ">Item 5."
#           item_parse <- sub(pattern = paste(".*", item[1], sep = "")[1], "", x[loc_item[1]], ignore.case = F) # updated July 15, 2023
#           item_txt <- sub(pattern = "(>|)(Item|ITEM)[^_].*", "", item_parse) 
#         }
#         
#       } else { # if the id is NOT long enough 
#         # print("Yes! item_id")
#         item_parse <- sub(pattern = paste(".*", item[2], sep = "")[1], "", x[loc_item[1]], ignore.case = F)
#         item_txt <- sub(pattern = "(>|)(Item|ITEM).*", "", item_parse) ## July 14, 2023 
#       }
#       
#     }
#   } else {
#     # the full item ## *updated August 18, 2023 
#     if (any(is.na(item_id))) { 
#       item_txt <- paste(str_squish(x[loc_item[1]:loc_item[2]]), collapse = "") %>% 
#         sub(pattern = paste(".*", item[2], sep = "")[1], "", ., ignore.case = F) %>% 
#         sub(pattern = "(>)?(Item|ITEM)(.){0,30}[6-9]\\b.*", "", .) ## *updated August 18, 2023 
#       
#     } else {
#       item_txt <- paste(str_squish(x[loc_item[1]:loc_item[2]]), collapse = "")
#       
#     }
#     
#     # item_txt <-  paste(str_squish(x[loc_item[1]:loc_item[2]]), collapse = " ") %>% 
#     #   sub(pattern = paste(".*", item[2], sep = "")[1], "", ., ignore.case = F) %>%
#     #   sub(pattern = "(>|)(Item|ITEM).*", "", .) ## August 7, 2023 
#   }
#   
#   # find the table(s) ## *updated August 9, 2023 
#   res <- try(item_html <- read_html(paste("<text>", item_txt, "</text>", collapse = "")), silent = T) 
#   if (inherits(res, "try-error")) {
#     if (nchar(x[loc_item[1]]) > 300) {
#       item_parse <- sub(pattern = paste(".*", item[2], sep = "")[1], "", paste(item_txt, collapse = " "), ignore.case = T) ## July 14, 2023 
#       item_txt <- sub(pattern = "(>)?(Item|ITEM)[^0-9]+\\d{1}.*", "", item_parse)
#       res <- try(item_html <- read_html(paste(item_txt, collapse = "")), silent = T)
#     }
#     res2 <- try(item_html <- read_html(paste('<p>', item_txt, '</p>', collapse = "")), silent = T)
#   } 
#   
#   item_tbls <- html_nodes(item_html, "table")
#   if (length(item_tbls) == 0) { # if no table found in the item 
#     # print("No Table!")
#     ## print("k5")
#     return(list(table = matrix(NA, nrow = 1, ncol = 4),
#                 parts = "No Table!" , # html_text(item_html, trim = T),  
#                 table_unit = NA,
#                 table_html_code = NA ))
#   } else { # if there are tables! ## updated August 8, 2023 
#     item_tbl_id <- which(str_count(string = as.character(item_tbls), pattern = "/tr") > 1 & # number of rows > 1
#                            str_count(string = as.character(item_tbls), pattern = "/td") / str_count(string = as.character(item_tbls), pattern = "/tr") >= 6 & # number of columns >= 6
#                            grepl(pattern = "Total.*Number|purchase|repurchase", x = item_tbls, ignore.case = T) & 
#                            grepl(pattern = "program|price|plan", x = item_tbls, ignore.case = T) & 
#                            grepl(pattern = "share", x = item_tbls, ignore.case = T) & 
#                            !grepl(pattern = "issuance|revenue|income|conversion|(purchase price of common)", x = item_tbls, ignore.case = T) )[1] # identify the correct table
#     ## id: "0001403475-21-000015"
#     
#     ## extract the table 
#     if (ifelse(is.na(item_tbl_id), 
#                FALSE, # if no table is identified
#                grepl(pattern = "total.*number.*of|Average.*Price.*Paid",
#                      x = html_text(item_tbls[[item_tbl_id]]),
#                      ignore.case = T) # check again the table is correct
#     )
#     ) { 
#       ### <Tables starts here!>
#       ### clean the table ## *updated August 22, 2023 
#       item_table0 <- unique.matrix(as.matrix(html_table(item_tbls[[item_tbl_id]], header = F)), MARGIN = 2) %>% 
#         .[,colSums(is.na(.)) != nrow(.),drop=F]
#       item_table0 <- apply(item_table0, MARGIN = 2, FUN = function(x) gsub(x = x, pattern = "\\([a-zA-Z0-9]{1}\\)", replacement = "") %>% trimws)
#       if (nrow(item_table0) > 6) {
#         item_table0_footnotes <- sapply(apply(item_table0, MARGIN = 1, FUN = function(x) {
#           table(x[nchar(x, type = "width") >= 3], exclude = "") # exclude "" elements > collect the frequency of appearance in each row  
#         }), FUN = function(x) {
#           if (length(x) == 1) {
#             output <- as.logical(x > ncol(item_table0)/2)
#           } else { # id "0000732717-14-000110.txt" ## *updated August 22, 2023 
#             if (length(x) == 2) {
#               output <- as.logical(x[which.max(x)] > ncol(item_table0)/2)
#             } else {
#               output <- FALSE
#             }
#           }
#           return(output)
#         }) 
#         item_table0_footnotesid <- which((item_table0_footnotes +
#                                             dplyr::lead(item_table0_footnotes, default = 1) + 
#                                             dplyr::lead(item_table0_footnotes, 2, default = 1)) == 3)[1]
#         item_table0_head <- which(apply(item_table0, MARGIN = 1,
#                                         FUN = function(x) sum({grepl(pattern = "total|number|average|price", x, ignore.case = T)}, na.rm = T) ) > 0)[1]
#         if (!is.na(item_table0_footnotesid) & (item_table0_footnotesid > item_table0_head) ) { # if the footnote is identified 
#           item_table0 <- item_table0[1:max(1,item_table0_footnotesid-1),,drop=F]
#         }
#       }
#       
#       ### remove rows with all same elements 
#       if ( sum(grepl(pattern = "total.*number.*of|Average.*Price.*(Paid)?|Maximum.*number", x = item_table0[,1], ignore.case = T)) > 1 ) { 
#         # for the case: "0001144204-17-014104" ## sum(item_table0[1,] %in% month.name) > 0
#         item_table0 <- item_table0 %>%
#           .[, colSums(. == "$") == 0 & !is.na(colSums(. == "$")), drop=F] # remove columns having only $ or NA 
#         item_table0 <- t(item_table0)
#       }  
#       ## (abandoned*) grepl(pattern = "border-bottom", html_nodes(item_tbls[[item_tbl_id]], "tr")) # try to identify the header row
#       ### check empty rows and remove them 
#       if ( length(which(apply(item_table0, MARGIN = 1, FUN = function(x) sum(nchar(na.omit(x)), na.rm = T)) == 0)) > 0 ) {
#         item_table2 <- item_table0[-which(apply(item_table0, MARGIN = 1, FUN = function(x) sum(nchar(x), na.rm = T)) == 0),,drop=F] # remove empty rows
#         
#       } else {
#         item_table2 <- item_table0
#       } ## *updated August 19, 2023 
#       
#       
#       ## whether has `$`: ## *updated August 18, 2023 
#       item_table_dollar <- rep("", ncol(item_table2))
#       item_table_dollar[which(colSums(item_table2 == "$", na.rm = T) > 0) + 1] <- "D$-" # record the column that is in dollar ($)
#       # item_table2[1,] <- paste(item_table_dollar, item_table2[1,,drop=F], sep = "") # replace the old column headers by the new ones with ($)
#       
#       item_table3 <- item_table2 %>% 
#         rbind(item_table_dollar, ., deparse.level = 0) %>% # add the symbol ($) info in the first row 
#         .[, colSums(. == "$", na.rm = T) == 0 & colSums(is.na(item_table2)) != nrow(item_table2), drop=F] %>% # remove columns having only $ or NA (past code: <!is.na(colSums(. == "$"))> )
#         unique.matrix(x = ., MARGIN = 2)  # remove repeated columns 
#       # if (any(is.na(item_table3))) { # if there still exists NA elements -> replace it by dash 
#       #   item_table3[is.na(item_table3)] <- "NA"
#       # }
#       item_table <- item_table3 %>% 
#         .[apply(., MARGIN = 1, FUN = function(x) length((unique(x)))) != 1,,drop=F] %>% # remove merged rows 
#         .[,apply(., MARGIN = 2, FUN = function(x) sum(nchar(x, type = "width"))) != 0,drop=F] # remove zero width columns 
#       
#       ### identify the rows to keep ## *updated August 22, 2023 
#       # item_table_headerid <- 0; item_table_headerid0 <- 100
#       # while ((item_table_headerid0 != item_table_headerid) & !any(grepl(pattern = "///", x = item_table, fixed = T))) {
#       
#       #### the header row ## *updated August 22, 2023 
#       item_table_headercount <- apply(item_table, 1, FUN = function(x) sum(grepl(pattern = "plan|program|purchased", x = x, ignore.case = T)))
#       if (max(item_table_headercount) == 0 ) { # id "0001217234-21-000046"
#         item_table_headercount <- apply(item_table, 1, FUN = function(x) sum(grepl(pattern = "price|number|total", x = x, ignore.case = T)))
#       } 
#       ## *updated August 23, 2023 
#       potential_header_idcheck <- sapply(X = which(item_table_headercount > 0), FUN = function(x) {
#         # get the full header up to a row: from row 2 to row `x`
#         headername <- apply(item_table[max(2, x-2):x,,drop=F], MARGIN = 2, FUN = function(y) paste(y, collapse = "") ) # get the full header up to a row
#         ## count the unique (non empty) headers there  
#         uniq_headername <- grep(pattern = "[a-zA-Z]", x = unique(headername), value = T) %>% length() 
#         # get the row text and count the unique items in each row (for the case that footnotes cannot be fully removed)
#         headername_row <- grep(pattern = "[a-zA-Z]", x = unique(item_table[x,,drop=T]), value = T) %>% length() 
#         uniq_headername[(headername_row == 1)] <- 0
#         return(uniq_headername) # return the number 
#       })
#       
#       #### following code explanation: `item_table_headerid` ## *updated August 22, 2023 
#       #### (1) [.] > identify the rows with the most number of unique items 
#       #### (2) max(.) > find the row number of the qualified rows and choose the last row among them 
#       item_table_headerid <- max(which(item_table_headercount>0)[which(potential_header_idcheck == max(potential_header_idcheck))]) ## record the number of cells with letters in each row 
#       item_table_headerid0 <- max(which(item_table_headercount == max(item_table_headercount))) 
#       if (item_table_headerid0 != item_table_headerid) {
#         new_row <- item_table[item_table_headerid0,]
#         if (item_table_headerid0 < item_table_headerid) {
#           new_row[nchar(new_row, type = "width") != 0] <- gsub(pattern = "$", "///", new_row[nchar(new_row, type = "width") != 0] )
#           # sub("///.*", "", new_row) # to extract the info afterwards 
#           item_table[item_table_headerid0,] <- new_row
#         } else {
#           item_table[item_table_headerid0,] <- ""
#         }
#       }
#       
#       ### record the column ids for rownames (row-headers) ## *updated August 19, 2023 
#       item_table_colheaders <- which(cumsum(grepl(pattern = "total|number|purchase|average", ignore.case = T, 
#                                                   x = apply(item_table[min(2, item_table_headerid):item_table_headerid,,drop=F], # pick the header rows 
#                                                             MARGIN = 2, FUN = function(x) paste(x, collapse = " ")) ) )  == 0 )
#       if (length(item_table_colheaders) == 0) { # e.g. "0001564590-21-004296" 
#         item_table_colheaders <- which(cumsum((!duplicated(apply(item_table[min(2, item_table_headerid):item_table_headerid,,drop=F], # pick the header rows
#                                                                  MARGIN = 2, FUN = function(x) paste(x, collapse = " ")) ) ) ) == 1 )
#       }
#       
#       #### replace the NA in the matrix entry
#       item_table <- apply(item_table, MARGIN = 2, FUN = function(x) replace_na(x, "N/A"))
#       
#       #### the number rows to keep (after removing the header row(s) )
#       if (nrow(item_table[-(1:item_table_headerid), -item_table_colheaders, drop = F]) > 4) {
#         item_table_numbersid <- item_table_headerid + 
#           which(apply(item_table[-(1:item_table_headerid), -item_table_colheaders, drop = F], 1, FUN = function(x) sum(grepl("\\W|\\w", x))) != 0)
#       } else {
#         item_table_numbersid <- (item_table_headerid+1):nrow(item_table)  
#       }
#       
#       #### the first column with row info ## *updated August 19, 2023 
#       if (length(item_table_colheaders) > 1) { # if multiple first columns
#         item_table <- cbind(
#           as.matrix(apply(item_table[,item_table_colheaders,drop=F], 1, FUN = function(x) paste(unique(x[nchar(x, type = "width") != 0]), collapse = " - "))), 
#           item_table[,-item_table_colheaders, drop=F] 
#         )
#       } 
#       
#       #### the new `period` variable and rows to be kept 
#       tbl_rowkeep_info <- tbl.rowkeep2(row_name = item_table[,1], reporting_qrt = reporting_qrt)
#       
#       if (NA %in% tbl_rowkeep_info) { # IF THE TABLE IS NOT VALID
#         ## no actual table can be identified 
#         ## print("k3")
#         return(list(table = matrix(NA, nrow = 1, ncol = 4),
#                     parts = html_text(item_html, trim = T),  
#                     table_unit = NA, 
#                     table_html_code = NA ))
#       } else { 
#         ## Continue for a valid table      
#         tbl_periods <- tbl_rowkeep_info$period # return the period for each column 
#         tbl_rowkeep <- tbl_rowkeep_info$rowkeep # identify the rows to be kept in `item_table`
#         
#         ### clean rows in the table 
#         tbl_numbers <- item_table %>% .[tbl_rowkeep, ,drop=F] %>% # keep the rows after the headers
#           cbind(., `length<-`(tbl_periods, nrow(.))) %>%  # add 'period' column 
#           .[match(item_table_numbersid[item_table_numbersid >= (tbl_rowkeep)[1]], tbl_rowkeep), ,drop=F] # keep the rows with values 
#         
#         ### create the tbl_titles
#         if (item_table_headerid == 1) {
#           tbl_title0 <- item_table[item_table_headerid,-1,drop=T] %>%
#             gsub(pattern = "\\([a-zA-Z0-9]{1}\\)", replacement = "", x = .) %>% 
#             trimws %>% as.vector
#         } else {
#           tbl_title0 <- apply(item_table[1:item_table_headerid,-1,drop=F], MARGIN = 2,
#                               FUN = function(name) paste(name, collapse = " ") ) %>%
#             gsub(pattern = "\\([a-zA-Z0-9]{1}\\)", replacement = "", x = .) %>%
#             trimws %>% as.vector
#         }
#         ### to impute missing headers
#         tbl_title0[which(nchar(tbl_title0, type = "width") == 0)] <- tbl_title0[which(nchar(tbl_title0, type = "width") == 0)-1]
#         tbl_title <- c("item", (tbl_title0), "period") ## final headers 
#         
#         ### store duplicated and non-duplicated column headers
#         tbl_title_dupid <- cumsum(!duplicated(gsub("D\\$-|\\s", "", tbl_title)))
#         
#         if (max(tbl_title_dupid) < length(tbl_title)) { # if there are duplicated headers
#           tbl_numbers <- sapply(X = 1:max(tbl_title_dupid), FUN = function(x) {
#             apply(tbl_numbers[, which(tbl_title_dupid == x),drop=F], MARGIN = 1, FUN = function(x) paste(unique(x), collapse = " ")) %>% 
#               str_replace_all(pattern = "\\$|(\\s*?)\\([12ab]\\)", replacement = "")
#           })
#           
#           if (is.null(dim(tbl_numbers))) {
#             tbl_numbers <- matrix(tbl_numbers, nrow = 1)
#           }
#           ## clean the wired values (id "0001039684-11-000029")
#           if (sum(str_count(tbl_numbers[,1], pattern = "[a-zA-Z]") == str_count(tbl_numbers[,2], pattern = "[a-zA-Z]")) > nrow(tbl_numbers)/2 ) {
#             tbl_numbers[,c(-1, -ncol(tbl_numbers))] <- apply(tbl_numbers[,c(-1, -ncol(tbl_numbers)), drop=F], MARGIN = 2,
#                                                              FUN = function(x) str_replace_all(string = x, pattern = paste(tbl_numbers[,1], collapse = "|"), replacement = ""))
#           }
#           
#         } ## otherwise just use the old tbl_numbers 
#         
#         #### append back the column headers
#         colnames(tbl_numbers) <- tbl_title[!duplicated(tbl_title_dupid)] 
#         
#         ### return the cleaned table - from wide to long
#         tbl_numbers_cleaned <- melt(as.data.frame(tbl_numbers), id.vars = c("item", "period")) 
#         
#         ## <table unit information>
#         ## extract the unit information from the table ## updated July 16, 2023
#         item_table_unit <- str_extract(string = html_text(item_tbls[[item_tbl_id]], trim = T), pattern = "\\((I|i)(N|n)\\s*[^()0-9c][^()0-9]+\\)")
#         if (is.na(item_table_unit)) { # check directly in the table if the `item_table_unit` returns NA 
#           item_table_unit <- grep(pattern = "in\\s*(hundred|thousand|million|billion)", x = item_table0, ignore.case = T, value = T)[1]
#         } 
#         
#         ## <text info excl. table> ## *updated August 22, 2023 (issues)
#         ## extract item text and exclude the table. ## *updated August 22, 2023 
#         table_html_code <- as.character(item_tbls[[item_tbl_id]]) # store the raw html code for the table 
#         xml_replace(.x = item_tbls[[item_tbl_id]], .value = text_break_node) # replace the identified table
#         filing_item2_txt <- html_text(item_html, trim = T) # store the txt excl. table
#         if (is.na(item_table_unit)) { # if no unit info inside the table
#           ## search in the text before the table 
#           item_table_unit <- str_extract(string = sub(pattern = "<footnote>.*", replacement = "", x = filing_item2_txt),
#                                          pattern = "\\((I|i)(N|n)\\s*[^()0-9c][^()0-9]+\\)")
#         }
#         
#         # tbl_numbers_cleaned %>% View
#         ## print("k2")
#         return(list(table = as.matrix(tbl_numbers_cleaned), 
#                     parts = filing_item2_txt,
#                     table_unit = item_table_unit, 
#                     table_html_code = table_html_code
#         ) )
#       }
#     } else { # if no table in the item ## *updated August 22, 2023 
#       ## print("k1")
#       return(list(table = matrix(NA, nrow = 1, ncol = 4),
#                   parts = substr(html_text(item_html, trim = T), 1, 5000), # keep only the first 5000 char
#                   table_unit = NA,
#                   table_html_code = NA ))
#     }
#   }
# }
# 
# 
# # h2. filing.item_purchase(): extract text (header and/or footnote), unit and cleaned table ---- 
# # copied from SEC_web_v3cfunctions.R: (https://github.com/hongyileoxu/hongyileoxu.github.io/blob/main/research/RepurchaseProject/SEC_web_v3cfunctions.R)
# # extract the information/contents in the text
# # 
# ## Arg: 
# ##    x: Character. The text file in characters. Use the `filing_structured` rather than the `filing`. 
# ##       The end of each element of the given character should be a closing tag. 
# ##    loc_item: the location of the item of interest and should be a vector containing two numerical values. 
# ##    item_id: the identifer from 'href' for the item of interest and should be a vector containing two series of strings. 
# ##    item: the regex for the item of interest and should be a vector containing the regex for the item name and the item number. 
# ##    item_id_backup: a backup id. 
# ##  *above four inputs are generated from function `loc.item()` or `loc.item7()` 
# ##    reporting_qrt: the reporting quarter of the filing. 
# ##    item_regex: the regex to identify the content of interest. 
# ##    text_break_node: the XML to replace the identified table. 
# ##    table: logical. If TRUE, the table is scrapped. 
# ##    parts: indicate the parts of information that you want: 
# ##      -: == "note" when look into Item 8. 
# ##
# ## Output: 
# ##    table: the extracted table in the long format in a n-by-4 matrix. 
# ##           the table is extrated based on the `item_regex` provided in the input. 
# ##           each column corresponds to the item, payment due information, the value of payment due and the maturity of the obligation. 
# ##    parts: vector. the extracted cleaned text information for Item 7. 
# ##    table_unit: the unit of numbers in the extracted table. 
# ##    table_html_code: the raw html code for the extracted table. 
# #     
# ## EDGAR Filings: 
# #   (1) https://www.sec.gov/ix?doc=/Archives/edgar/data/320193/000032019319000119/a10-k20199282019.htm 
# #   (2) [done] https://www.sec.gov/Archives/edgar/data/1045810/000104581019000023/nvda-2019x10k.htm 
# #   (3) https://www.sec.gov/Archives/edgar/data/320193/000032019321000105/aapl-20210925.htm#icffec2d5c553492089e1784044e3cc53_76 
# #   (4) https://www.sec.gov/Archives/edgar/data/1173281/000138713119000051/ohr-10k_093018.htm#ohr10k123118a010 
# #   (5) https://www.sec.gov/ix?doc=/Archives/edgar/data/16732/000001673224000130/cpb-20240728.htm 
# #   (6) https://www.sec.gov/ix?doc=/Archives/edgar/data/0001730168/000173016823000096/avgo-20231029.htm [Broadcom Inc. > The table is not under Item 7, but under Note 13.]
# 
# filing.item_purchase <- function(x, # filing
#                                  loc_item, # the location of the item of interest
#                                  # item_id, # [deprecated] the identifier from 'href' for the section 
#                                  item, # the regex for the item (item number./ item name)
#                                  item_id_backup, # a backup id ## *August 8, 2023 
#                                  reporting_qrt, # the quarter the filing was made 
#                                  item_regex, # the regex to identify whether the information of interest exists 
#                                  # text_break_node, # [deprecated] the xml to replace the identified table
#                                  table = TRUE, # whether to scrap the table numbers 
#                                  parts = c("footnote") # the parts of information that you want 
# ) { 
#   # `loc_item` cannot be NA! 
#   # step 1. extract the text given the information {loc_item, item_id, item, item_id_backup}
#   ##Output: 
#   ##     item_txt: raw text for item 7. 
#   #     
#   item_txt <- str_squish(paste(x[loc_item[1]:loc_item[2]], collapse = " "))  
#   
#   # step 2. find the table(s) 
#   res <- try(item_html <- read_html(paste("<text>", item_txt, "</text>", collapse = "")), silent = T) 
#   # browsable(HTML(as.character(item_html))) # browse the html version of the extracted text 
#   
#   if (inherits(res, "try-error")) {
#     if (nchar(x[loc_item[1]]) > 300) {
#       item_parse <- sub(pattern = paste(".*", item[2], sep = "")[1], "", item_txt, ignore.case = T) ## July 14, 2023 
#       item_txt <- sub(pattern = "(>)?(Item|ITEM)[^0-9]+\\d{1}.*", "", item_parse)
#       browsable(HTML(as.character(item_txt)))
#       res <- try(item_html <- read_html(paste(item_txt, collapse = "")), silent = T)
#     }
#     res2 <- try(item_html <- read_html(paste('<p>', item_txt, '</p>', collapse = "")), silent = T)
#   } 
#   
#   # step 3. extract the table(s) 
#   item_tbls <- html_nodes(item_html, "table")
#   # browsable(HTML(as.character(item_tbls)))
#   ## find the table that match 
#   item_tbl_id <- grep(pattern = item_regex, x = item_tbls, ignore.case = TRUE, perl = TRUE)
#   
#   # tt_test <- html_to_table(tbl_html = item_tbls[[item_tbl_id]],
#   #                                                html_text(read_html(x[loc_item[1]])),
#   #                                                allcurrency = TRUE )
#   # tt_test$table ## *updated Oct 11, 2024 ==== 
#   
#   if (length(item_tbl_id) > 0) {
#     ## if a valid `item_tbl_id` can be found
#     # item_tbls[item_tbl_id] %>% html_table() 
#     ### <Tables starts here!>
#     # step 3.1. convert the table into a matrix format. 
#     ### clean the table ## *updated August 22, 2023 
#     item_table0 <- unique.matrix(as.matrix(html_table(item_tbls[[item_tbl_id]], header = F)), MARGIN = 2) %>% 
#       .[,colSums(is.na(.)) != nrow(.),drop=F] # drop all NA or duplicated columns.
#     item_table0 <- apply(item_table0, MARGIN = 2, FUN = function(x) gsub(x = x, pattern = "\\([a-zA-Z0-9]{1}\\)", replacement = "") %>% trimws) %>% 
#       `dimnames<-`(value = NULL)
#     
#     ### modify if the table is too big. 
#     ### needs to be updated to better identify the footnotes: Task: Oct 9, 2024 ==== 
#     {
#       # if (nrow(item_table0) > 5) { 
#       #   # record the location of footnotes in the table. 
#       #   ## output: `item_table0_footnotes` contains a vector of logical showing which row contains footnotes. 
#       #   item_table0_footnotes <- sapply(
#       #     # for each row in the table, record the frequency of each unique string. 
#       #     apply(item_table0, MARGIN = 1, FUN = function(x) {
#       #       table(x[nchar(x, type = "width") >= 3], exclude = "") # exclude "" elements > collect the frequency of appearance in each row  
#       #     }), ## output: a list with non-empty unique elements and their frequency. 
#       #     # for each element in the list, 
#       #     ## (1) check the number 
#       #     FUN = function(x) {
#       #       if (length(x) == 1) {
#       #         output <- as.logical(x > ncol(item_table0)/2)
#       #       } else { # id "0000732717-14-000110.txt" ## *updated August 22, 2023 
#       #         if (length(x) == 2) {
#       #           output <- as.logical(x[which.max(x)] > ncol(item_table0)/2)
#       #         } else {
#       #           output <- FALSE
#       #         }
#       #       }
#       #       return(output)
#       #     })
#       #   
#       #   # record the id of footnotes in the table, if exists. 
#       #   item_table0_footnotesid <- which((item_table0_footnotes +
#       #                                       dplyr::lead(item_table0_footnotes, default = 1) + 
#       #                                       dplyr::lead(item_table0_footnotes, 2, default = 1)) == 3)[1]
#       #   # record the id of the header row in the table. 
#       #   item_table0_head <- which(apply(item_table0, MARGIN = 1,
#       #                                   FUN = function(x) sum({grepl(pattern = "payment|due", x, ignore.case = T)}, na.rm = T) ) > 0)[1]
#       #   if (!is.na(item_table0_footnotesid) & (item_table0_footnotesid > item_table0_head) ) { 
#       #     # if the footnote is identified 
#       #     item_table0 <- item_table0[1:max(1,item_table0_footnotesid-1),,drop=F]
#       #   }
#       # }
#       # 
#     } # [deprecated!]  
#     
#     # step 3.2. clean the rows in the table 
#     ### remove rows with all same elements 
#     ### first check whether the table needs to be transposed. 
#     if ( any(grepl(pattern = "(?=.(due|in|after)[^[:alpha:]])*", # updated Oct 9, 2024 
#                    x = item_table0[,1], ignore.case = TRUE, perl = TRUE)) & 
#          !any(grepl(pattern = item_regex,
#                     x = item_table0[,1], ignore.case = TRUE, per = TRUE)) ) { 
#       # for the case: "0001144204-17-014104" ## sum(item_table0[1,] %in% month.name) > 0
#       item_table0 <- item_table0 %>% 
#         .[, colSums(. == "$") == 0 & !is.na(colSums(. == "$")), drop=F] # remove columns with only $ or NA 
#       item_table0 <- t(item_table0) 
#     }  
#     
#     ### check and remove empty rows 
#     if ( length(which(apply(item_table0,
#                             MARGIN = 1,
#                             FUN = function(x) sum(nchar(na.omit(x)), na.rm = T)) == 0)) > 0 ) {
#       
#       item_table2 <- item_table0[-which(apply(item_table0, MARGIN = 1, FUN = function(x) sum(nchar(x), na.rm = T)) == 0),,drop=F] # remove empty rows
#       
#     } else {
#       item_table2 <- item_table0
#     } ## *updated August 19, 2023 
#     
#     # step 3.3. record the unit $ for the rows and columns with numbers 
#     ## whether has `$`: ## *updated September 30, 2024 
#     ## `$`s are used to identify headers/body and true columns. 
#     item_table_dollar <- rep("", ncol(item_table2))
#     item_table_dollar[which(colSums(item_table2 == "$", na.rm = T) > 0) + 1] <- "D$-" # record the column that is in dollar ($)
#     ## check by each row whether the '$' exists. 
#     item_table_body <- apply(item_table2, MARGIN = 1, FUN = function(x) {
#       sum(grepl(pattern = "$", x = x, fixed = TRUE))
#     })
#     ## identify the starting row that contain information
#     item_table_headerid <- which(item_table_body > 0)[1] ## header is before this line 
#     
#     # step 3.4. finish the pre-cleaning of the table 
#     ## output: variable `item_table` contains the result 
#     item_table3 <- item_table2 %>% 
#       rbind(item_table_dollar, ., deparse.level = 0) %>% # add the symbol ($) info in the first row 
#       .[, colSums(. == "$", na.rm = T) == 0 & colSums(is.na(item_table2)) != nrow(item_table2), drop=F] %>% # remove columns having only $ or NA (past code: <!is.na(colSums(. == "$"))> )
#       unique.matrix(x = ., MARGIN = 2)  # remove repeated columns 
#     
#     item_table <- item_table3 %>% 
#       .[apply(., MARGIN = 1, FUN = function(x) length((unique(x)))) != 1,,drop=F] %>% # remove merged rows 
#       .[,apply(., MARGIN = 2, FUN = function(x) sum(nchar(x, type = "width"))) != 0,drop=F] # remove zero width columns 
#     
#     # step 3.5. locate and extract the header row(s) in the table 
#     {
#       ##### [deprecated] #### the header row ## *updated August 22, 2023 
#       # item_table_headercount <- apply(item_table, 1,
#       #                                 FUN = function(x) 
#       #                                   sum(grepl(pattern = "(?=.(due|in|after)[^[:alpha:]])",
#       #                                             x = x, ignore.case = T, perl = TRUE)))
#       # if (max(item_table_headercount) == 0 ) { # id "0001217234-21-000046"
#       #   item_table_headercount <- apply(item_table, 1, FUN = function(x) sum(grepl(pattern = "pay", x = x, ignore.case = T)))
#       # } 
#       ##### [deprecated] ## *updated September 30, 2024
#       # potential_header_idcheck <- sapply(X = which(item_table_headercount > 0), FUN = function(x) {
#       #   # get the full header up to a row: from row 2 to row `x`
#       #   headername <- apply(item_table[max(2, x-2):x,,drop=F], MARGIN = 2, FUN = function(y) paste(y, collapse = "") ) # get the full header up to a row
#       #   ## count the unique (non empty) headers there  
#       #   uniq_headername <- grep(pattern = "[a-zA-Z]", x = unique(headername), value = T) %>% length() 
#       #   # get the row text and count the unique items in each row (for the case that footnotes cannot be fully removed)
#       #   headername_row <- grep(pattern = "[a-zA-Z]", x = unique(item_table[x,,drop=T]), value = T) %>% length() 
#       #   uniq_headername[(headername_row == 1)] <- 0
#       #   return(uniq_headername) # return the number 
#       # })
#       
#       ##### [deprecated] following code explanation: `item_table_headerid` ## *updated September 30, 2024 
#       # #### (1) [.] > identify the rows with the most number of unique items 
#       # #### (2) max(.) > find the row number of the qualified rows and choose the last row among them 
#       # item_table_headerid <- max(which(item_table_headercount>0)[which(potential_header_idcheck == max(potential_header_idcheck))]) ## record the number of cells with letters in each row 
#       # item_table_headerid0 <- max(which(item_table_headercount == max(item_table_headercount))) 
#       # if (item_table_headerid0 != item_table_headerid) {
#       #   new_row <- item_table[item_table_headerid0,]
#       #   if (item_table_headerid0 < item_table_headerid) {
#       #     new_row[nchar(new_row, type = "width") != 0] <- gsub(pattern = "$", "///", new_row[nchar(new_row, type = "width") != 0] )
#       #     # sub("///.*", "", new_row) # to extract the info afterwards 
#       #     item_table[item_table_headerid0,] <- new_row
#       #   } else {
#       #     item_table[item_table_headerid0,] <- ""
#       #   }
#       # }
#     } # [deprecated]
#     
#     ### the header name may be spread across several rows. 
#     ### record the column ids for rownames (row-headers), ## *updated August 19, 2023 
#     ### which is the column for all rownames and no data information. 
#     item_table_colheaders <- which(
#       cumsum(
#         grepl(
#           pattern = "pay|due|in|after|purcha", ignore.case = T, 
#           x = apply(
#             item_table[min(2, item_table_headerid):item_table_headerid,,drop=F], # pick all rows contain the header information 
#             MARGIN = 2, FUN = function(x) paste(x, collapse = " ")
#           ) 
#         ) 
#       )  == 0 ) 
#     if (length(item_table_colheaders) == 0) { # e.g. "0001564590-21-004296" 
#       item_table_colheaders <- which(cumsum((!duplicated(apply(item_table[min(2, item_table_headerid):item_table_headerid,,drop=F], # pick the header rows
#                                                                MARGIN = 2, FUN = function(x) paste(x, collapse = " ")) ) ) ) == 1 )
#     }
#     
#     #### replace the NA in the matrix entry
#     item_table <- apply(item_table, MARGIN = 2, FUN = function(x) replace_na(x, "N/A"))
#     
#     ##### [deprecated] #### the id of rows to keep (after removing the column and row headers )
#     # if (nrow(item_table[-(1:item_table_headerid), -item_table_colheaders, drop = F]) > 3) {
#     #   item_table_numbersid <- item_table_headerid + 
#     #     which(apply(item_table[-(1:item_table_headerid), -item_table_colheaders, drop = F], 
#     #                 MARGIN = 1, FUN = function(x) sum(grepl("\\W|\\w", x))) != 0) 
#     # } else {
#     #   item_table_numbersid <- (item_table_headerid+1):nrow(item_table)  
#     # } 
#     
#     #### the first column with row info ## *to update: Oct 9, 2024 ====  
#     #### if multiple first column is found, combine elements in the same row and set it as the new rowname. 
#     if (length(item_table_colheaders) > 1) { # if multiple first columns
#       item_table <- cbind(
#         as.matrix(apply(
#           item_table[,item_table_colheaders,drop=F], MARGIN = 1,
#           FUN = function(x) paste(unique(x[nchar(x, type = "width") != 0]), collapse = " - ")
#         ) ) ,  
#         item_table[,-item_table_colheaders, drop=F] 
#       )
#     } 
#     
#     # step 3.6. clean and keep the rows with information in the table. 
#     #### the new `period` variable and rows to be kept 
#     #### [deprecated] all information will be kept at this stage, 
#     ####    also the function `tbl.rowkeep2()` is specifically for repurchase tables. 
#     tbl_rowkeep_info <- tbl.rowkeep2(regex_row = "\\w",
#                                      row_name = item_table[,1], reporting_qrt = reporting_qrt)
#     
#     if (NA %in% tbl_rowkeep_info) { # IF THE TABLE IS NOT VALID 
#       ## no actual table can be identified 
#       ## print("k3")
#       ## Oct 10, 2024 ==== 
#       ### get the cleaned text in blocks. 
#       filing_item2_txt <- as.character(item_html) %>%
#         clean_html2(input_string = ., pattern = "</[a-zA-Z]+>\\s*</[a-zA-Z]+>\\s*<[^/!]") %>%  
#         sapply(X = ., FUN = function(x) html_text(read_html(x), trim = TRUE) ) %>% 
#         as.vector() %>% 
#         .[. != ""] # store the txt excl. table
#       
#       ### identify and locate the relevant text
#       
#       
#       ### extract the text and convert information into a table format 
#       
#       
#       ### return the output 
#       return(list(table = matrix(NA, nrow = 1, ncol = 4),
#                   parts = filing_item2_txt,  
#                   table_unit = NA, 
#                   table_html_code = NA ))
#     } else {
#       ## if a proper table is identified 
#       #    ## Continue for a valid table    
#       tbl_rowkeep <- tbl_rowkeep_info$rowkeep %>% .[. > item_table_headerid] # identify the rows to be kept in `item_table`
#       tbl_periods <- tbl_rowkeep_info$period %>% .[tbl_rowkeep_info$rowkeep > item_table_headerid] # return the period for each column 
#       
#       ### clean rows in the table and exclude the header rows. 
#       tbl_numbers <- item_table %>% .[tbl_rowkeep, ,drop=F] %>% # keep the rows after the headers
#         # cbind(., `length<-`(tbl_periods, nrow(.))) %>%  # add 'period' column
#         .[match(tbl_rowkeep[tbl_rowkeep >= (tbl_rowkeep)[1]], tbl_rowkeep), ,drop=F] # keep the rows with values
#       
#       ### create the tbl_titles
#       if (item_table_headerid == 1) {
#         ## if column headers are in one cell each, 
#         tbl_title0 <- item_table[item_table_headerid,-1,drop=T] %>%
#           ## remove any number labels (e.g. (1)) 
#           gsub(pattern = "\\([a-zA-Z0-9]{1}\\)", replacement = "", x = .) %>% 
#           trimws %>% as.vector
#       } else {
#         ## if column headers are spreaded to multiple cells in each column, 
#         ## collapse cells in each column and store the full column name. 
#         tbl_title0 <- apply(item_table[1:item_table_headerid,-1,drop=F], MARGIN = 2,
#                             FUN = function(name) paste(name, collapse = " ") ) %>% 
#           ## remove any number labels (e.g. (1)) 
#           gsub(pattern = "\\([a-zA-Z0-9]{1}\\)", replacement = "", x = .) %>%
#           trimws %>% as.vector
#       }
#       
#       ### to impute missing headers
#       tbl_title0[which(nchar(tbl_title0, type = "width") == 0)] <- tbl_title0[which(nchar(tbl_title0, type = "width") == 0)-1]
#       tbl_title <- c("item", (tbl_title0)) ## final headers 
#       
#       # step 3.7. clean the columns. 
#       ### store duplicated and non-duplicated column headers
#       tbl_title_dupid <- cumsum(!duplicated(gsub("D\\$-|\\s", "", tbl_title)))
#       
#       if (max(tbl_title_dupid) < length(tbl_title)) { # if there are duplicated headers
#         ## clean and remove the columns with duplicated 
#         tbl_numbers <- sapply(X = 1:max(tbl_title_dupid), FUN = function(x) {
#           apply(tbl_numbers[, which(tbl_title_dupid == x),drop=F], MARGIN = 1, 
#                 FUN = function(x) 
#                   paste(unique(x), collapse = " ")) %>% 
#             str_replace_all(pattern = "\\$|(\\s*?)\\([12ab]\\)", replacement = "")
#         })
#         
#         if (is.null(dim(tbl_numbers))) {
#           tbl_numbers <- matrix(tbl_numbers, nrow = 1)
#         }
#         ## clean the wired values (id "0001039684-11-000029")
#         if (sum(str_count(tbl_numbers[,1], pattern = "[a-zA-Z]") == str_count(tbl_numbers[,2], pattern = "[a-zA-Z]")) > nrow(tbl_numbers)/2 ) {
#           tbl_numbers[,c(-1, -ncol(tbl_numbers))] <- apply(tbl_numbers[,c(-1, -ncol(tbl_numbers)), drop=F], MARGIN = 2,
#                                                            FUN = function(x) str_replace_all(string = x, pattern = paste(tbl_numbers[,1], collapse = "|"), replacement = ""))
#         }
#         
#       } ## otherwise just use the old tbl_numbers 
#       
#       #### append back the column headers
#       colnames(tbl_numbers) <- tbl_title[!duplicated(tbl_title_dupid)] 
#       
#       # step 3.8. convert table from wide to long. 
#       ### return the cleaned table - from wide to long
#       tbl_numbers_cleaned <- melt(as.data.frame(tbl_numbers), id.vars = c("item")) %>% 
#         left_join(x = .,
#                   ## `y` here ranks the sequence of each item, from less than 1 year to more than e.g. 5 years. 
#                   y = select(., variable) %>% 
#                     unique() %>% 
#                     mutate(period = str_extract_all(string = variable, pattern = "\\d+(\\.\\d+)?") ) %>% 
#                     unnest(cols = period) %>% 
#                     mutate(period = as.integer(period)) %>% 
#                     group_by(variable) %>% 
#                     summarise(rank = mean(period) ) %>% 
#                     ungroup() %>% 
#                     mutate(rank = rank(rank)), 
#                   by = "variable" 
#         ) 
#       
#       # step 3.9. extract the unit information for numbers in the table. 
#       ## <table unit information>
#       ## extract the unit information from the table ## updated July 16, 2023
#       item_table_unit <- str_extract(string = html_text(item_tbls[[item_tbl_id]], trim = T), pattern = "\\((I|i)(N|n)\\s*[^()0-9c][^()0-9]+\\)")
#       if (is.na(item_table_unit)) { # check directly in the table if the `item_table_unit` returns NA 
#         item_table_unit <- grep(pattern = "in\\s*(hundred|thousand|million|billion)",
#                                 x = item_table0, ignore.case = T, value = T)[1]
#       } 
#       
#       ## <text info excl. table> ## *updated August 22, 2023 (issues)
#       ## extract item text and exclude the table. ## *updated August 22, 2023 
#       table_html_code <- as.character(item_tbls[[item_tbl_id]]) # store the raw html code for the table 
#       xml_replace(.x = item_tbls[[item_tbl_id]], .value = text_break_node) # replace the identified table
#       filing_item2_txt <- as.character(item_html) %>%
#         clean_html(input_string = ., pattern = "</[a-zA-Z]+>\\s*</[a-zA-Z]+>\\s*<[^/!]") %>%  
#         apply(MARGIN = 2, FUN = function(x) html_text(read_html(x), trim = TRUE) ) %>% 
#         as.vector() %>% 
#         .[. != ""] # store the txt excl. table
#       
#       if (is.na(item_table_unit)) { 
#         ## if still no unit info inside the table
#         ## identify the location of the table (`item_table_loc`) in the text. 
#         item_table_loc <- grep(pattern = "<footnote>", x = filing_item2_txt)
#         ## search in the text before the table 
#         item_table_unit <- str_extract_all(string = filing_item2_txt[item_table_loc - (1:2)],
#                                            pattern = "\\((I|i)(N|n)\\s*[^()0-9c][^()0-9]+\\)",
#                                            simplify = T) %>% 
#           as.vector() 
#       }
#       
#       ## print("k2") 
#       return(list(table = as.matrix(tbl_numbers_cleaned), # cbind.data.frame(tbl_numbers_cleaned, unit = item_table_unit) 
#                   parts = filing_item2_txt,
#                   table_unit = item_table_unit, 
#                   table_html_code = table_html_code
#       ) ) 
#     }
#     
#   } else {
#     ## if no valid `item_tbl_id` can be identified: 
#     ## e.g. Apple 10K in 2021: https://www.sec.gov/Archives/edgar/data/320193/000032019321000105/aapl-20210925.htm#icffec2d5c553492089e1784044e3cc53_76
#     # print("No Table!")
#     ## print("k5")
#     ## Oct 9, 2024 
#     
#     ### get the cleaned text in blocks. 
#     #### cleaned html txt blocks. 
#     filing_item7_rawhtml <- as.character(item_html) %>%
#       clean_html2(input_string = ., pattern = "</[a-zA-Z]+>\\s*</[a-zA-Z]+>\\s*<[^/!]") 
#     #### extract the text from the html blocks. 
#     filing_item7_txt <- filing_item7_rawhtml %>%  
#       sapply(X = ., FUN = function(x) html_text(read_html(x), trim = TRUE) ) %>% 
#       as.vector() # %>% # store the txt excl. table
#     # .[. != ""] # remove empty elements in the vector
#     
#     #### count the number of words in each block and identify the block as the sub-item header. 
#     filing_item7_txtcount <- filing_item7_txt %>% 
#       str_count(string = ., pattern = "[a-zA-Z]+")
#     filing_item7_txtcount[grepl(pattern = "^(\\W)*[a-z]|(\\|)|^[0-9\\s]+$|([Tt]able [Oo]f)|[;$]", x = filing_item7_txt) | (filing_item7_txtcount == 0)] <- -1 # exclude strings with (1) "|", (2) not starting with capital letter or (3) no text count. 
#     filing_item7_headerid <- which(filing_item7_txtcount <= 8 & filing_item7_txtcount > 0) # the row id (relative to `filing_item7_txt`) for potential headers, including sub-headers. 
#     # filing_item7_txt[filing_item7_headerid]
#     
#     {
#       # #### extract the html attributes for all nodes in each html block. 
#       # filing_item7_attributes <- filing_item7_rawhtml[filing_item7_headerid] %>% 
#       #   sapply(X = .,
#       #          FUN = function(x) 
#       #            unique(na.omit(html_attr(html_elements(read_html(x), "*"), name = "style"))) %>% 
#       #            paste(collapse = ";") %>% 
#       #            gsub(pattern = ";padding[^;]+;", replacement = ";", x = .) %>% 
#       #            gsub(pattern = ";;", replacement = ";", x = ., fixed = T),
#       #          USE.NAMES = FALSE)
#       # #### record the all headers and their locations in the raw html file. 
#       # filing_item7_allheaders <- sapply(X = unique(filing_item7_attributes), 
#       #        FUN = function(x) 
#       #          cbind(
#       #            name = filing_item7_txt[filing_item7_headerid[which(filing_item7_attributes == x)]], 
#       #            rowid = filing_item7_headerid[which(filing_item7_attributes == x)]
#       #          ) ) 
#       # #### record just the sub-headers and their locations in the raw html file. 
#       # filing_item7_subheaders <- filing_item7_allheaders %>% 
#       #   # subitem_regex = "accounting"
#       #   .[grep(x = ., pattern = "accounting", ignore.case = T)] %>%  # as the disclosure on "Critical accounting judgments" is required. 
#       #   do.call(what = rbind, args = .)
#       #     
#       # #### the table of contents for the item (not the full filing, just the item. e.g. Item 7.) 
#       # #### `filing_item7_toc` contains information for the name, the row id and an identifier for each paragraph/section header. 
#       # filing_item7_toc <- do.call(what = rbind, args = filing_item7_allheaders) %>% 
#       #   as_tibble() %>% 
#       #   mutate(rowid = as.integer(rowid)) %>% 
#       #   arrange(rowid) %>% 
#       #   mutate(headeryes = (name %in% filing_item7_subheaders[, "name"]) ) 
#     } # [deprecated] 
#     
#     ### extract the relevant item (purchase obligation/contract/etc.) and its number(s)  
#     ### keep the sentences in the paragrpah if it contains numbers or e.g. "Note 9"
#     filing_item7_extracted <- filing_item7_extract(filing_txt = filing_item7_txt,
#                                                    filing_headerid = filing_item7_headerid,
#                                                    item_regex = item_regex) 
#     
#     ### extract the text and convert information into a table format 
#     if (!is.null(filing_item7_extracted)) {
#       ## if matched text is found 
#       # e.g. https://www.sec.gov/ix?doc=/Archives/edgar/data/1543151/000154315124000012/uber-20231231.htm > [Uber Tech. > Purchase Commitment in Text]
#       
#       ## convert full sentences into tokens and return a matrix. 
#       ## tokens in the same row of the matrix come from the same sentence. 
#       filing_item7_tokens <- sapply(X = filing_item7_extracted, FUN = function(x) {
#         ## first, identify the sentence with the matched info by `item_regex`. 
#         text <- grep(pattern = item_regex, x = x, ignore.case = TRUE, perl = TRUE, value = TRUE) 
#         ## convert the full sentence into a vector of text tokens. 
#         text_vector <- str_split(string = text, pattern = "[:blank:]+") 
#       }, USE.NAMES = TRUE, simplify = TRUE) %>% 
#         ## convert the list of vectors into a matrix using function `vectors_to_matrix()`
#         vectors_to_matrix(vec_list = .) 
#       
#       ## correct the row names for each item / the row name in the matrix `filing_item7_tokens`.  
#       wrongnameid <- grep(pattern = paste(str_extract_all(string = item_regex, pattern = "\\w+", simplify = TRUE),
#                                           collapse = "|" ), 
#                           x = rownames(filing_item7_tokens), 
#                           ignore.case = TRUE, perl = TRUE, value = FALSE, invert = TRUE) 
#       ### if there are irregular row-names (sub-item names) -> replace it by the name from the paragraph. 
#       if (length(wrongnameid) > 0) { 
#         ## update the irregular row names 
#         rownames(filing_item7_tokens)[wrongnameid] <- 
#           filing_item7_tokens[wrongnameid,,drop = F] %>% 
#           apply(MARGIN = 1, FUN = function(x) { 
#             ## get the location of matched words 
#             ids <- grep(pattern = gsub(pattern = "\\W+", replacement = "|", x = item_regex) %>%
#                           gsub("^\\||\\|$", "", x= .), 
#                         x = x, ignore.case = TRUE, perl = TRUE, value = FALSE) 
#             ## enrich the text by adding the one word before the matched words 
#             full_ids <- c(min(ids) - 1, ids) 
#             ## return the full text outputs 
#             output <- paste(x[full_ids] , collapse = " ")
#             return(output) 
#           }) %>% as.vector() 
#       }
#       
#       ## extract the content numbers from the text. 
#       largeunits_regex <- "thousand|milli|bill|tril" # regex to identify the number units. 
#       ## classify and tabulate numbers (from text!!!)
#       ## output: `tbl_numbers_fromtext` is a matrix 
#       tbl_numbers_fromtext <- 
#         sapply(X = 1:nrow(filing_item7_tokens), FUN = function(x) {
#           text <- filing_item7_tokens[x,]
#           var_name <- rownames(filing_item7_tokens)[x] 
#           ## function `text_to_table()` pick the dollar values. 
#           result <- text_to_table(text = text, var_name = var_name, largeunits_regex = largeunits_regex)
#           return(result) 
#         }, simplify = F) %>% 
#         do.call(what = rbind, args = .) 
#       
#       if (dim(tbl_numbers_fromtext)[2] == 4) {
#         ## if the output is what we want! 
#         ## continue my quest: Oct 8, 2024 ---- 
#         tbl_numbers_cleaned <- tbl_numbers_fromtext %>% 
#           mutate(unit = gsub("\\W", "", unit)) 
#         
#         item_table_unit <- unique(tbl_numbers_cleaned$unit) 
#         
#         ## final outputs  
#         return(list(table = as.matrix(tbl_numbers_cleaned), # cbind.data.frame(tbl_numbers_cleaned, unit = item_table_unit) 
#                     parts = filing_item7_txt, # a word vector for the whole section7. 
#                     table_unit = item_table_unit, 
#                     table_html_code = filing_item7_extracted)) # a list containing text information. 
#         
#       } else {
#         ## if the output does not include anything. 
#         return()
#         
#       }
#       
#     } else {
#       ## if no matched text is found 
#       ## e.g. in this case. CIK: 1730168; Year: 2022; 
#       #   (6) https://www.sec.gov/ix?doc=/Archives/edgar/data/0001730168/000173016823000096/avgo-20231029.htm 
#       ## [Broadcom Inc. > The table is not under Item 7, but under Note 13.] 
#       
#       
#       
#     }
#     
#     
#     
#     ### return the output 
#     return(list(table = matrix(NA, nrow = 1, ncol = 4),
#                 parts = filing_item7_txt,  
#                 table_unit = NA, 
#                 table_html_code = NA ))
#     
#   }
#   
# }
# 
# 
