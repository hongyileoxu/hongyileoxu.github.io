# debug: 
#
# {
#   filing_path <- grouped_full_path[[2]][86] 
# }
#

filing_to_PurchaseTables <- function(filing_path) {
  # for a given file path: > this can be written into a new function for convenience[!]
  
  ## step 1. read the file and extract information 
  filing <- readLines(archive::archive_read(data_dir_yearzip, filing_path))
  
  ### create a more structured file for the main body of the document 
  filing_structured <- 
    filing[(grep("<DOCUMENT>", filing, ignore.case = TRUE)[1]):
             (grep("</DOCUMENT>", filing, ignore.case = TRUE)[1])] %>% 
    paste(., collapse = " ") %>% 
    str_squish() %>% 
    clean_html2(input_string = ., 
                pattern = c("(</\\w+\\s*>\\s*)<([^/>]+>\\s*<[^/>]+>)",
                            "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])")) %>% # *updated Oct 19, 2024   
    as.vector() 
  
  ### get the filing headers 
  # filing_header <-
    # filing.header(x = filing)
  
  ## step 2. get the purchase obligation information 
  {
    ## Item 7: 
    # cat("Information to locate Item 7 in the 10-K filing:") 
    loc_item7 <- loc.item_MDnA(x = filing_structured, filing_type = "10-K")
    
    ## Extract the table: 
    ### From Item 7: 
    cat("Item 7: ") 
    if (all(is.na(loc_item7$item_id))) {
      cat("Not exist. \n")
      return(NULL) 
    }
    item7_purchase <- filing.10kitem_purchase(x = filing_structured,
                                              loc_item = loc_item7$loc_item, 
                                              item_regex = "\\bpurchas[a-z]+\\s+\\b(obligat|commitment|agreement|order|contract)"
                                              )
    if ("table" %in% names(item7_purchase)) {
      ## if only one output > the usual case 
      item7_purchase <- item7_purchase[c("table", "table_unit")]
    } else {
      ## if there are multiple outputs 
      ## e.g. "2019/QTR1/20190208_10-K_edgar_data_22606_0001628280-19-001107.txt"
      item7_purchase <- sapply(X = item7_purchase,
                               FUN = function(x) { x[c("table", "table_unit")] },
                               simplify = FALSE, USE.NAMES = TRUE) 
    }
    
    
    ## Item 8: 
    loc_item8 <- loc.item_MDnA(x = filing_structured,
                               filing_type = "10-K", 
                               regex_item = c(NA, "(?=.*finan)(?=.*statem)(?=.*supple)(?=.*data)"), # item header 
                               regex_num = c("[>](Item|ITEM)[^0-9]+2\\.", "[>](Item|ITEM)[^0-9]+8\\."), # item number 
                               regex_perl = TRUE) 
    cat("Item 8: ")
    if (all(is.na(loc_item8$item_id))) {
      cat("Not exist. \n")
      return(list(item7_purchase = item7_purchase)) 
    }
    item8_notes_html <- filing.item8_notes(x = filing_structured, 
                                           loc_item = loc_item8$loc_item, 
                                           item_regex = "\\bpurchas[a-z]+\\s+\\b(obligat|commitment|agreement|order|contract)",
                                           # "(?=.purchas)(?=.(obligation|commitment|agreement|order|contract))" 
                                           # "\\bpurchas[^\\.]*\\b(obligat|commitment|agreement|order|contract)" 
                                           note_regex = NULL) %>% 
      ## Drop the elements return NULL: 
      Filter(Negate(is.null), .)
    
    if (is.null(unlist(item8_notes_html))) { # if nothing from Item 8, just return Item 7 extracted info. 
      cat("NULL \n")
      return(list(item7_purchase = item7_purchase))
    }
    
    ## Extract the table: only if item8_notes_html != NULL. 
    ### From Item 8: 
    item8_purchase <- sapply(X = item8_notes_html, FUN = function(x) { 
      sapply(X = x, FUN = function(x) {
        filing.10kitem_purchase(x = x,
                                loc_item = c(1, length(x)),
                                item_regex = "\\bpurchas[a-z]+\\s+\\b(obligat|commitment|agreement|order|contract)") %>% 
          .[c("table", "table_unit")] 
      }, USE.NAMES = TRUE, simplify = FALSE) 
    }, simplify = FALSE, USE.NAMES = TRUE)
    #### further assign each element in the list into a single variable.
    #### (1) adjust the name of the list first. 
    names(item8_purchase) <- paste("item8", letters[1:length(item8_purchase)], "_purchase", sep = "") 
    
    sapply(X = names(item8_purchase), FUN = function(name) { 
      purchase_subnote <- item8_purchase[[name]] %>% 
        `names<-`(value = paste(name, 1:length(.), sep = "")) 
      ## split the whole list into basic lists inside the function environment: `environment()`. 
      list2env(purchase_subnote, envir = parent.env(environment()) ) 
    })
    
    ## merge all purchasing tables into one. 
    item_purchase <- mget(grep(pattern = "^item(7|8\\w)(_purchase)\\d*",
                          x = ls(envir = environment() ), value = TRUE)) 
    }
  
  return(item_purchase)
  
}
