# function: filing.10kitem_purchase(): ---- 
## * this is for 10-K only. 
# extract text (header and/or footnote), unit and cleaned table from 10-K filings. 
# based on SEC_web_v3cfunctions.R: (https://github.com/hongyileoxu/hongyileoxu.github.io/blob/main/research/RepurchaseProject/SEC_web_v3cfunctions.R)
# extract the information/contents in the text
# 
## Arg: 
##    x: character: The text file in characters. Use the `filing_structured` rather than the `filing`. 
##       The end of each element of the given character should be a closing tag. 
##    loc_item: integer: a two element vector for the location of the item of interest and should be a vector containing two numerical values. 
##       * This input is generated from function `loc.item_MDnA()` or I can manually choose.  
##    item_regex: character: the regex to identify the content of interest. 
##       For purchasing obligations: 
##        (1) "(?=.*purchas)(?=.*(obligation|commitment|agreement|order|contract))" 
##        (2) "\\bpurchas[^\\.]*\\b(obligat|commitment|agreement|order|contract)" 
## 
###############################################################
### [deprecated Args:]
##    reporting_qrt: the reporting quarter of the filing. 
##    table: logical. If TRUE, the table is scrapped. 
##    parts: indicate the parts of information that you want: 
##      -: == "note" when look into Item 8. 
###############################################################
## 
## Output: 
##    table: matrix: the extracted table in the long format in a n-by-4 matrix. 
##                    the table is extracted based on the `item_regex` provided in the input. 
##                    each column corresponds to the item, payment due information, 
##                    the value of payment due and the maturity of the obligation. 
##    parts: character: the extracted cleaned text information for Item 7. 
##    table_unit: character: the unit of numbers in the extracted table. 
##    table_html_code: character : the raw html code for the extracted table. 
#     
## EDGAR Filings: 
#   (1) https://www.sec.gov/ix?doc=/Archives/edgar/data/320193/000032019319000119/a10-k20199282019.htm 
#   (2) [done] https://www.sec.gov/Archives/edgar/data/1045810/000104581019000023/nvda-2019x10k.htm 
#   (3) https://www.sec.gov/Archives/edgar/data/320193/000032019321000105/aapl-20210925.htm#icffec2d5c553492089e1784044e3cc53_76 
#   (4) https://www.sec.gov/Archives/edgar/data/1173281/000138713119000051/ohr-10k_093018.htm#ohr10k123118a010 
#   (5) https://www.sec.gov/ix?doc=/Archives/edgar/data/16732/000001673224000130/cpb-20240728.htm 
#   (6) https://www.sec.gov/ix?doc=/Archives/edgar/data/0001730168/000173016823000096/avgo-20231029.htm [Broadcom Inc. > The table is not under Item 7, but under Note 13.]
##
# debug 1 : 
# {
#   x = item8_notes_html[[1]][[1]]
#   loc_item = c(1, length(x))
#   item_regex = "\\bpurchas[a-z]+\\s+\\b(obligat|commitment|agreement|order|contract)"
#   item_regex_alt = "(?=.*purchas)(?=.*(obligation|commitment|agreement|order|contract))"
# }
# debug 2: 
# {
#   x = filing_structured 
#   loc_item = loc_item7$loc_item 
#   item_regex = "\\bpurchas[a-z]+\\s+\\b(obligat|commitment|agreement|order|contract)"
#   item_regex_alt = "(?=.*purchas)(?=.*(obligation|commitment|agreement|order|contract))"
# }
## 
# 

filing.10kitem_purchase <- function(x, # filing
                                    loc_item, # the location of the item of interest
                                    item_regex = "(?=.*\\bpurchas)(?=.*(obligation|commitment|agreement|order|contract))", # Moon and Phillips (2020) # the regex to identify whether the information of interest exists 
                                    item_regex_alt = "(?=.*\\bpurchas)(?=.*(obligation|commitment|agreement|order|contract))" # alternative regex for the item. 
                                    # reporting_qrt, # the quarter the filing was made 
                                    # table = TRUE, # whether to scrap the table numbers 
                                    # parts = c("footnote") # the parts of information that you want 
) { 
  # `loc_item` cannot be NA! 
  
  # step 1. extract the text given the information {loc_item, item_id, item, item_id_backup}
  #     
  item_txt <- str_squish(paste(x[loc_item[1]:loc_item[2]], collapse = " "))  
  
  # step 2. find the table(s) 
  res <- try(item_html <- read_html(paste("<text>", item_txt, "</text>", collapse = "")), silent = T) 
  # browsable(HTML(as.character(item_html))) # browse the html version of the extracted text 
  
  if (inherits(res, "try-error")) {
    if (nchar(x[loc_item[1]]) > 300) {
      item_parse <- sub(pattern = paste(".*", item[2], sep = "")[1], "", item_txt, ignore.case = T) ## July 14, 2023 
      item_txt <- sub(pattern = "(>)?(Item|ITEM)[^0-9]+\\d{1}.*", "", item_parse)
      browsable(HTML(as.character(item_txt)))
      res <- try(item_html <- read_html(paste(item_txt, collapse = "")), silent = T)
    }
    res2 <- try(item_html <- read_html(paste('<p>', item_txt, '</p>', collapse = "")), silent = T)
  } 
  
  # step 3A. extract the table(s) 
  item_tbls <- html_nodes(item_html, "table") %>% 
    # exclude cases e.g. "2019/QTR1/20190131_10-K_edgar_data_822416_0000822416-19-000008.txt" 
    .[sapply(X = ., FUN = function(x) str_count(as.character(x), pattern = "td"),
           simplify = TRUE, USE.NAMES = FALSE) > 16] 
  # browsable(HTML(as.character(item_tbls)))
  ## find the table that match 
  item_tbl_id <- grep(pattern = item_regex, x = item_tbls, ignore.case = TRUE, perl = TRUE) 
    # Debug: find the matched text:  
    # matches <- gregexpr(pattern = item_regex, text = as.character(item_tbls), perl = TRUE, ignore.case = TRUE)
    # matched_substrings <- regmatches(as.character(item_tbls), matches)
    # print(matched_substrings) 
  
  ## double check the table if the previous algo cannot find any, 
  if (length(item_tbl_id) == 0) {
    item_tbl_id <- grep(pattern = item_regex_alt, x = item_tbls, ignore.case = TRUE, perl = TRUE) 
    ### and update the regex if required! 
    if (length(item_tbl_id) > 0) {
      item_regex <- item_regex_alt
    } 
  } 
  
  if (length(item_tbl_id) > 0) { 
    
    if (length(item_tbl_id) > 1) { 
      # > "2019/QTR1/20190131_10-K_edgar_data_902739_0001166691-19-000005.txt" 
      item_tbl_id <- item_tbl_id[which(sapply(X = item_tbls[item_tbl_id],
                                              FUN = function(x) 
                                                str_count(string = as.character(x), pattern = "td"), 
                                              USE.NAMES = FALSE, simplify = TRUE) > 100)]
    } ## *updated Oct 15, 2024 
    
    tbl_colname <- html_text(read_html(x[loc_item[1]]))
    if (length(item_tbl_id) > 1) {
      ## if a valid `item_tbl_id` exists[!]
      cat(paste(length(item_tbl_id), " ", sep = "")) 
      ## if more than one element 
      output <- sapply(X = item_tbl_id, FUN = function(id) {
        output_i <- html_to_table(tbl_html = item_tbls[[id]], 
                                item_html = item_html, 
                                tbl_html_id = id, 
                                tbl_colname = tbl_colname,
                                item_regex = item_regex, 
                                allcurrency = TRUE)
        return(output_i)
      }, simplify = FALSE, USE.NAMES = TRUE) %>% 
        `names<-`(value = paste("subsidary", item_tbl_id, sep = ""))
    } else {
      ## if a valid `item_tbl_id` exists[!] 
      ## only one element 
      res <- try(output <- html_to_table(tbl_html = item_tbls[[item_tbl_id]], 
                                         item_html = item_html, 
                                         tbl_colname = tbl_colname,
                                         item_regex = item_regex, 
                                         allcurrency = TRUE), silent = TRUE) 
    } 
    
    if (!is.null(output)) {
      ### if `output` is valid [!] 
      cat("Table, Yes!\n") 
      return(output) 
    } 
  }   
  
  # step 3B. if no information can be extracted from the table, 
  #          look into the text and extract the table info. 
  {
    ## if a valid `item_tbl_id` does not exist [x] > search in the text 
    
    ### step 3B-1&2: get the cleaned text and location for sub-headers from the HTML. 
    filing_item7_info <- html_to_structure(item_html = item_html) 
    
    ### step 3B-3: choose the subsections containing information matching `item_regex`.
    ###            and filter the sentences in the chosen subsections that contain number(s). 
    ### extract the relevant item (purchase obligation/contract/etc.) and its number(s)  
    ### keep the sentences in the paragrpah if it contains numbers or e.g. "Note 9"
    filing_item7_extracted <- filing_item7_extract(filing_txt = filing_item7_info$text,
                                                   filing_headerid = filing_item7_info$headerid,
                                                   item_regex = item_regex) 
    
    ### check if matched text exists? 
    if (!is.null(filing_item7_extracted)) {
      ## if matched text is found [!] 
      # >>> [Uber Tech. > Purchase Commitment in Text]
      # e.g. https://www.sec.gov/ix?doc=/Archives/edgar/data/1543151/000154315124000012/uber-20231231.htm 
      
      ### step 3B-4&5: tokenise filtered sentences
      filing_item7_tokens <- text_to_tokens(sentences = filing_item7_extracted,
                                            item_regex = item_regex)
      
      ### step 3B-6: convert text info to the table. 
      ## extract the content numbers from the text. 
      largeunits_regex <- "thousand|milli|bill|tril" # regex to identify the number units. 
      ## classify and tabulate numbers (from text!!!)
      ## output: `tbl_numbers_fromtext` is a matrix 
      tbl_numbers_fromtext <- 
        sapply(X = 1:nrow(filing_item7_tokens), FUN = function(x) {
          text <- filing_item7_tokens[x,]
          var_name <- rownames(filing_item7_tokens)[x] 
          ## function `text_to_table()` pick the dollar values. 
          result <- text_to_table(text = text, var_name = var_name, largeunits_regex = largeunits_regex)
          return(result) 
        }, simplify = F) %>% 
        do.call(what = rbind, args = .) 
      
      
      if (dim(tbl_numbers_fromtext)[2] == 4) {
        ## if the output is what we want! 
        ## continue my quest: Oct 12, 2024 ---- 
        tbl_numbers_cleaned <- tbl_numbers_fromtext %>% 
          mutate(unit = gsub("\\W", "", unit)) 
        
        item_table_unit <- unique(tbl_numbers_cleaned$unit) 
        
        ## final outputs  
        cat("Table, Yes!\n") 
        return(list(table = as.matrix(tbl_numbers_cleaned), # cbind.data.frame(tbl_numbers_cleaned, unit = item_table_unit) 
                    parts = filing_item7_info$text, # a word vector for the whole section7. 
                    table_unit = item_table_unit, 
                    table_html_code = filing_item7_extracted)) # a list containing text information. 
        
      } else {
        ## if the output is unusual. > table is not reported. 
        ## e.g. "2019/QTR1/20190131_10-K_edgar_data_773141_0001437749-19-001602.txt" 
        cat("Unusual table output!\n")
        return(list(table = NULL,
                    parts = filing_item7_info$text, # a word vector for the whole section7. 
                    table_unit = NULL, # omitted. 
                    table_html_code = filing_item7_extracted)) # a list containing text information. > just for double-check. 
      }
      
      
    } else {
      ## if matched text is not found [x] 
      cat("No matched text!\n")
      ## e.g. in this case. CIK: 1730168; Year: 2022; 
      #   (6) https://www.sec.gov/ix?doc=/Archives/edgar/data/0001730168/000173016823000096/avgo-20231029.htm 
      ## [Broadcom Inc. > The table is not under Item 7, but under Note 13.] 
      
      return(list(table = NULL,
                  parts = filing_item7_info$text, # a word vector for the whole section7. 
                  table_unit = NULL, # omitted. 
                  table_html_code = filing_item7_extracted)) # which is NULL. 
    } 
    
  }
}
