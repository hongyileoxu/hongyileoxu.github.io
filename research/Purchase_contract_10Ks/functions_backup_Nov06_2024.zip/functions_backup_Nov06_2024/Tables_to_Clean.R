# Tables_to_Clean: 
# 
# 
# 

Tables_to_Clean <- function(datafile_fullpath # the full path of the data file 
                            ) {
    ### load the data into the function environment 
    load(datafile_fullpath, envir = environment())
    # ## all 10-K full path
    # sec_10K_fullpath <- sapply(item_purchase_year, FUN = function(item){
    #   return(item$file) 
    # }, simplify = TRUE, USE.NAMES = FALSE) %>% unlist() 
    # ## 10-K full path for multiple items
    # sec_10K_multiple <- sapply(item_purchase_year, FUN = function(item){
    #   if (any(grepl(pattern = "item8", x = names(item$data), fixed = TRUE))) {return(item$file)}
    # }, simplify = TRUE, USE.NAMES = FALSE) %>% unlist() 
    assign("item_purchase_year", get(ls(pattern = "item_purchase_\\d+")) )
  
  # 
  # { Debug: 
  #   for (id in seq_along(item_purchase_year)) {
  #     if (!any(item$data == "Error!")) {
  #       # for correct outputs, get the item that a table is from 
  #       data <- item_purchase_year[[id]]$data
  #       full_path <- item$file
  #       data_itemnames <- names(data) 
  #       
  #       final_tables <- sapply(X = data_itemnames, FUN = function(itemname) {
  #         ## for each element in the data element: 
  #         if (grepl(pattern = "item7", x = itemname, fixed = TRUE) ) {
  #           ## extract the data from Item 7: 
  #           tbl_output <- tables_combine(data_item7 = data[[itemname]], full_path = full_path) 
  #         } else {
  #           ## extract the data from Item 7: 
  #           tbl_output <- table_combine(x = data[[itemname]], full_path = full_path) 
  #         }
  #         return(tbl_output) 
  #       }, simplify = FALSE, USE.NAMES = FALSE) %>% 
  #         do.call(what = rbind)
  #       
  #       # return(final_tables) 
  #     } 
  #   }
  # 
  # }
  # 
  
    ### clean the filings with proper information 
    ### extracted into a function? > function() ==== 
    tables <- sapply(X = item_purchase_year, FUN = function(item) {
      if (!any(item$data == "Error!")) {
        # for correct outputs, get the item that a table is from 
        data <- item$data
        full_path <- item$file
        data_itemnames <- names(data) 
        # data_item7 <- grep(pattern = "item7", x = data_itemnames, fixed = TRUE) 
        
        # Note*: 
        #   - Table outputs have column names: item, variable, value, rank. 
        #   - Text to Table outputs have column names: item, variable, value, unit. 
        #     - Table units are the same for Text to Table outputs. 
        #   > Check whether `"rank" %in% colname(table)` will be the way to go! 
        
        # Roadmap: 
        #   --- check whether item7 gives output 
        #    \- item 7 may have multiple tables named with  
        #   --- check whether item8 gives output 
        
        final_tables <- sapply(X = data_itemnames, FUN = function(itemname) {
          ## for each element in the data element: 
          if (grepl(pattern = "item7", x = itemname, fixed = TRUE) ) {
            ## extract the data from Item 7: 
            tbl_output <- tables_combine(data_item7 = data[[itemname]], full_path = full_path) 
          } else {
            ## extract the data from Item 7: 
            tbl_output <- table_combine(x = data[[itemname]], full_path = full_path) 
          }
          return(tbl_output) 
        }, simplify = FALSE, USE.NAMES = FALSE) %>% 
          do.call(what = rbind)
        
        return(final_tables) 
      } 
    }, simplify = FALSE) %>% 
      Filter(Negate(is.null), .)
    
    # tables %>% length()
    # View(tables[[1]])
    # E.g. 
    # > "2018/QTR1/20180112_10-K_edgar_data_1029744_0001029744-18-000006.txt" 
    # > "2018/QTR1/20180105_10-K-A_edgar_data_940942_0001564590-18-000122.txt" > wrong detection 
    
    rm(item_purchase_year)
    return(tables)
} 