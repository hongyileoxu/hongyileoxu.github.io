function(x, message = TRUE ) {
  if (message == TRUE) {
    sink("/dev/null")
  }
}