# table_combine(): 
# combine several outputs from the function `filing_to_PurchaseTables()` into one unified table ---- 
## write a new function to convert numbers in the text into a matrix output. 
## Arg: 
##    x: list: a list of with two elements - table and table_unit, which is the output of function `filing.10kitem_purchase()`
##    full_path: character: the full path of the file used as an id. 
##    
## Output: 
##    tbl_output: data.frame: record the output 
# 


table_combine <- function(x, full_path) {
  ## collect information about the table 
  tbl <- x$table 
  tbl_unit <- x$table_unit
  
  if (is.null(tbl) || dim(tbl)[1] < 1) { 
    ### check if the output does not exist. 
    return(NULL)
  } 
  
  if ( !any(grepl(pattern = "\\bpurchas[a-z]+\\s+\\b(obligat|commitment|agreement|order|contract)",
                 x = unique(tbl[,"item"]), perl = TRUE, ignore.case = TRUE)) ) {
    ### drop the output if no "purchase obligation" is identified. 
    return(NULL)
  }
  
  if ("rank" %in% colnames(tbl)) {
    ### for a regular output table from HTML tables 
    tbl_output <- cbind.data.frame(full_path = full_path, tbl, 
                                   unit = ifelse(is.null(tbl_unit), yes = NA, no = tbl_unit) ) %>% 
      dplyr::select(-rank, everything(), rank) 
    
  } else {
    ### check if the output table is from `text_to_table()` 
    tbl_output <- cbind.data.frame(full_path = full_path, tbl) %>% 
      mutate(rank = ifelse(grepl(pattern = "Total", x = variable, fixed = TRUE), yes = NA, no = 1) )
    
  }
  
  return(tbl_output)
}
