# For a given output by the `xml_structure()` or `html_structure()`, index each component in the HTML. 

# Example XML data
library(xml2)
xml_data <- read_xml("<root>
                        <child>
                          <subchild>Text1</subchild>
                        </child>
                        <child>
                          <subchild>Text2</subchild>
                        </child>
                     </root>")

# Capture the XML structure output > store the output from `xml_structure()` or `html_structure()`: 
xml_structure_output <- capture.output(xml_structure(xml_data)) 

# Function to compute indentation levels and hierarchical numbering
generate_hierarchy <- function(xml_structure_output) {
  
  # Helper function to determine indentation level
  get_indent_level <- function(line) {
    return(nchar(gsub("^\\S.*", "", line)))
  }
  
  # Initialize tracking variables
  levels <- list()
  hierarchy <- character(length(xml_structure_output))
  
  for (i in seq_along(xml_structure_output)) {
    indent_level <- get_indent_level(xml_structure_output[i])
    
    # Adjust levels list based on current indentation
    if (length(levels) < indent_level + 1) {
      levels[[indent_level + 1]] <- 1
    } else {
      levels[[indent_level + 1]] <- levels[[indent_level + 1]] + 1
    }
    
    # Remove extra levels when going up the hierarchy
    levels <- levels[seq_len(indent_level + 1)]
    
    # Generate the hierarchical number as a string (e.g., 1.1.1)
    hierarchy[i] <- paste(levels, collapse = ".")
  }
  
  # Combine the hierarchy with the original XML structure output
  result <- paste0(hierarchy, " ", xml_structure_output)
  return(result)
}

# Apply the function to generate hierarchy for xml_structure_output
indexed_structure <- generate_hierarchy(xml_structure_output)

# Print the indexed XML structure
cat(indexed_structure, sep = "\n")
