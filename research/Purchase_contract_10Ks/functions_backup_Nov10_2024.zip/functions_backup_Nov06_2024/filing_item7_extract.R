# filing_item7_extract(): 
# extract sentences in item 7 ---- 
## Arg: 
##    filing_txt: all txt in the item 7. 
##    filing_headerid: a vector of locations of all headers in item 7. 
##    item_regex: the regex to identify the matched text in item 7. 
##
## Output: 
##    output_txt: list. the extracted sentences under each sub-item if they are matched to the `item_regex`, and return NULL if no match is found. 
# 
# # 
# {
#   filing_txt = filing_item7_info$text
#   filing_headerid = filing_item7_info$headerid
#   item_regex = item_regex 
# }
# # 
# 

filing_item7_extract <- function(filing_txt, filing_headerid = NULL,
                                 item_regex = "(?=.*purchas)(?=.*(obligation|commitment|agreement|order|contract))") {
  ### identify the locate the relevant text 
  filing_txt_matched <- grep(pattern = item_regex, x = filing_txt,
                             ignore.case = TRUE, perl = TRUE, value = F)
  
  if (length(filing_txt_matched) == 0) {
    ## if `filing_txt_matched` is empty
    output_txt <- NULL
  } else {
    ## if `filing_headerid` is missing: 
    if (length(filing_headerid) == 0) {
      filing_headerid <- 1 
    }
    ## if only one break: 
    if (length(sort(unique(c(filing_headerid, length(filing_txt))))) == 1) {
      break_cuts <- sort(unique(c(filing_headerid, length(filing_txt) + 0.5)))
    } else {
      break_cuts <- sort(unique(c(filing_headerid, length(filing_txt) )))
    }
    ## if `filing_txt_matched` is not empty
    ### identify the sub-item of each relevant text 
    ### Cut the vector into groups based on breaks
    group_labels <- cut(x = filing_txt_matched,
                        breaks = break_cuts,
                        include.lowest = TRUE, right = FALSE)
    ### Split the vector based on the group labels
    split_numbers <- split(filing_txt_matched, group_labels, drop = TRUE)
    names(split_numbers) <- filing_txt[as.integer(gsub(pattern = "\\[([0-9]+),.*",
                                                       replacement = "\\1",
                                                       x = names(split_numbers)))]
    
    output_txt <- sapply(X = split_numbers, FUN = function(x) {
      ### extract and split the contents into sentences. 
      filing_sentences <- str_squish(unlist(strsplit(x = filing_txt[x], split = "(?<!\\d)(?<=\\.)\\s+", perl=TRUE))) 
      ### extract the sentences include the item numbers. 
      filing_sentences_items <- grep(pattern = "\\d+", # "|notes?[[:blank:]]*\\b\\d{1,2}" > this is redundant. 
                                     x = filing_sentences, ignore.case = TRUE, value = TRUE) %>% 
        grep(pattern = item_regex, ignore.case = TRUE, perl = TRUE, value = TRUE) 
      # if (length(filing_sentences_items) == 0) {filing_sentences_items <- NULL} 
      # return(filing_sentences_items) 
    }) %>% Filter(function(x) length(x) > 0, .) 
    
    if (length(output_txt) == 0) { output_txt <- NULL }
  } 
  return(output_txt)
} 