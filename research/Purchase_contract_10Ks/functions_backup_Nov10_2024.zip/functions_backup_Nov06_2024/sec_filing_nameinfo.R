# function: sec_filing_nameinfo(): ---- 
# extract information from the file path 
# 
## Arg: 
##    file_path: the full path name of files in the zip files. 
##    keep.original: whether keep the original full file path. TRUE is yes and FALSE is no. 
## Output: 
##    path_info: a n-by-5 matrix storing the information about qtr_calender, filing_date, file_type, CIK, accession_num in each column. 
#

sec_filing_nameinfo <- function(file_path, keep.original = TRUE) {
  path_cleaned <- str_extract(string = file_path, pattern = "QTR\\d/.*")
  path_info <- str_split(string = path_cleaned, pattern = "/|(_edgar_data_|_)", simplify = TRUE) %>% 
    `colnames<-`(value = c("qtr_calender", "filing_date", "file_type", "CIK", "accession_num"))
  if (isTRUE(keep.original)) {
    # if the full path is kept in the output
    path_info <- cbind(path_info, full_path = file_path)
  }
  return(path_info)
}