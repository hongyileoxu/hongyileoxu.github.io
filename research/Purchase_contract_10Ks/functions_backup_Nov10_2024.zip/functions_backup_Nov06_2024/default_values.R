# Store the default values which will be commonly used across different tasks. 

## Create a named vector for conversion.
num_map <- c("zero" = 0, "one" = 1, "two" = 2, "three" = 3, 
             "four" = 4, "five" = 5, "six" = 6, 
             "seven" = 7, "eight" = 8, "nine" = 9) 

## regex to identify the number units. 
largeunits_regex <- "thousand|milli|bill|tril" # regex to identify the number units. 
