# tables_combine(): 
# build on the function `table_combine()` ---- 
# handles multiple qualified tables. 
#
## Arg: 
##    data_item7: list: a list of outputs of function `filing.10kitem_purchase()`
##    full_path: character: the full path of the file used as an id. 
##    
## Output: 
##    data_item7_aggregate: data.frame: record the output 
# 


tables_combine <- function(data_item7, full_path) {
  ## if multiple elements are in Item 7: 
  if ( any(grepl(pattern = "subsid", x = names(data_item7), fixed = TRUE) ) ) {
    ## if there are multiple subsidiaries in the filing: 
    data_item7_aggregate <- sapply(data_item7, FUN = function(x) table_combine(x = x, full_path = full_path),
                                   simplify = FALSE, USE.NAMES = FALSE) %>% 
      do.call(what = rbind) 
  } else {
    ## if only one output 
    data_item7_aggregate <- table_combine(x = data_item7, full_path = full_path) 
  }
  
  return(data_item7_aggregate)
}

