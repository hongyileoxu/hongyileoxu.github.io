# function: text_to_tokens(): ---- 
# convert given sentences into word tokens. 
# function `vectors_to_matrix()` has to be imported. 
#
## Arg: 
##    sentences: list: a list containing sentences. 
##          Should be the output of function `filing_item7_extract()`, which is a list of characters. 
##    item_regex: character: the REGEX to select the sentences of interest. 
##
## Output: 
##    filing_item7_tokens: matrix: a matrix with each row represents information extracted from each sentence
##          and each column record one word from the sentence. NAs in each row can be omitted. 
##          
# 


text_to_tokens <- function(sentences, # a variable containing sentences. 
                           item_regex # REGEX to select the sentences of interest. 
                           ) {
  ### step 3B-4: tokenise filtered sentences in all selected subsections.  
  ## convert full sentences into tokens and return a matrix. 
  ## tokens in the same row of the matrix come from the same sentence. 
  filing_item7_tokens <- sapply(X = sentences, FUN = function(x) {
    ## first, identify the sentence with the matched info by `item_regex`. 
    text <- grep(pattern = item_regex, x = x, ignore.case = TRUE, perl = TRUE, value = TRUE) 
    ## convert the full sentence into a vector of text tokens. 
    text_vector <- str_split(string = text, pattern = "[:blank:]+") 
  }, USE.NAMES = TRUE, simplify = FALSE) %>% 
    ## ensure that every elements in the list is a vector (not another list) 
    do.call(what = c) %>% as.list() 
  
  if (length(filing_item7_tokens) == 0) {
    return(NULL)
  } else {
    ## convert the list of vectors into a matrix using function `vectors_to_matrix()`
    filing_item7_tokens <- vectors_to_matrix(vec_list = filing_item7_tokens) 
  }
  
  ### step 3B-5: double check the item names/rownames. 
  ## correct the row names for each item / the row name in the matrix `filing_item7_tokens`.  
  wrongnameid <- grep(pattern = paste(str_extract_all(string = item_regex, pattern = "(?<!\\\\)\\w{2,}", simplify = TRUE),
                                      collapse = "|" ), 
                      x = rownames(filing_item7_tokens), 
                      ignore.case = TRUE, perl = TRUE, value = FALSE, invert = TRUE) 
  ### if there are irregular row-names (sub-item names) -> replace it by the name from the paragraph. 
  if (length(wrongnameid) > 0) { 
    ## update the irregular row names 
    rownames(filing_item7_tokens)[wrongnameid] <- 
      filing_item7_tokens[wrongnameid,,drop = F] %>% 
      apply(MARGIN = 1, FUN = function(x) { 
        ## get the location of matched words 
        ids <- grep(pattern = item_regex, 
                      # paste(str_extract_all(string = item_regex,
                      #                               pattern = "(?<!\\\\)\\w{2,}",
                      #                               simplify = TRUE),
                      #               collapse = "|" ), 
                    x = x, ignore.case = TRUE, perl = TRUE, value = FALSE) 
        ## enrich the text by adding the one word before the matched words 
        full_ids <- c(min(ids) - 1, ids) 
        ## return the full text outputs 
        output <- paste(x[full_ids] , collapse = " ")
        return(output) 
      }) %>% as.vector() 
  }
  
  return(filing_item7_tokens) 
}












