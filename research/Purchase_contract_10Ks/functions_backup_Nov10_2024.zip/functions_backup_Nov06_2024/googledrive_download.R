# function: googledrive_download(): ----
# generate cmd code to download Google Drive files 
# 
## Arg: 
##    api_key: API key generated from Oauth 2.0 Playground by Google. 
##    file_info: a n-by-2 data.frame with sharing id in the first column and file name in the second column. 
##    file_link: the sharing id of the file on Google Drive. 
##    file_name: the name given to the downloaded file. 
##    to: the path for the downloaded files. 
## Output: 
##    cmd_output: curl commands to download file(s). 
# 

googledrive_download <- function(api_key, file_info, file_link, file_name, to = "/scratch/nhh/sec/") {
  if (missing(file_info)) { 
    # if argument `file_info` is not provided 
    cmd_output <- paste('curl -H "Authorization: Bearer ', api_key, '" ', "https://www.googleapis.com/drive/v3/files/", file_link, "?alt=media -o ", to, file_name, "   ", sep = "") 
  } else {
    # if argument `file_info` is provided 
    if (is.data.frame(file_info) & dim(file_info)[2] == 2) {
      cmd_output <- paste(apply(X = file_info, MARGIN = 1, FUN = function(x) paste('curl -H "Authorization: Bearer ', api_key, '" ', "https://www.googleapis.com/drive/v3/files/", x[1], "?alt=media -o ", to, "/", x[2], sep = "") ), collapse = ";  " )
    } else {
      stop("Error: 'file_info' parameter is not data.frame object or has more than 2 columns.")
    }
  }
  return(cmd_output)
} 
