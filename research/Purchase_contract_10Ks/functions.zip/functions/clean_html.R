# function: clean_html(): 
# clean the raw files and ensure contents in one tag not be broken into several parts ---- 
# *updated Oct 10, 2024 
# 
## Arg: 
##    input_string: one string with contents from `readLines()`. 
##    pattern: the regular expression used to match closing tags (</...>)
##      -: [ ] "</[a-zA-Z]+>\\s*</[a-zA-Z]+>\\s*<[^/]"
##      -: [ ] "(<\\/[a-zA-Z]+>\\s*<\\/[a-zA-Z]+>\\s*)<([^/])" 
##      -: [!] "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])" # the one used in this task 
##      -: [!] "(</\\w+\\s*>\\s*)<([^/>]+>\\s*<[^/>]+>)" # also the one used in the task 
##          |- third and fourth are combined into: "(</\\w+\\s*>\\s*)<([^/>]+>\\s*<[^/>]+>)|(</[^>]+>\\s*</[^>]+>\\s*)<([^/])"
## Output: 
##    result: the cleaned vector of strings. 
# 

clean_html <- function(input_string, 
                       pattern = c("(</\\w+\\s*>\\s*)<([^/>]+>\\s*<[^/>]+>)",
                                   "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])")) {
  if (length(pattern) > 1) {
    pattern_all <- paste(pattern, collapse = "|")
  } else {
    pattern_all <- pattern 
  }
  # Split the string but keep the closing tags in the result
  string_main <- unlist(strsplit(input_string, pattern_all, perl = TRUE))
  
  # Append the matched closing tags back into the result
  matches <- regmatches(input_string, gregexpr(pattern_all, input_string)) 
  
  # Modify the tags 
  string_tag <- lapply(X = matches, FUN = function(x)
    gsub(pattern = pattern[1], replacement = "\\1~B~<\\2", x) %>% 
      gsub(pattern = pattern[2], replacement = "\\1~B~<\\2", .) ) 
  
  # Combine the split strings and tags and re-split the string 
  result <- paste(c(rbind(string_main,
                          c(unlist(string_tag), "")[1:length(string_main)] )),
                    collapse = "") %>%
    str_split(pattern = "~B~", simplify = T)
  
  return(result)
}
