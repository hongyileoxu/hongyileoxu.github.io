# loc.item_MDnA(): 
# locate the item of interest: MD&A ---- 
# copied from SEC_web_v3cfunctions.R: (https://github.com/hongyileoxu/hongyileoxu.github.io/blob/main/research/RepurchaseProject/SEC_web_v3cfunctions.R)
# Return the location of the item of interest in the raw file specified in `x`. 
# 
## Arg: 
##    x: the text file in characters. 
##    filing_type: choose the type of filings. 10-K or 10-Q. 
##    regex_item: character: the regex for the item of interest in the table of contents. 
##    regex_num: character: the regex for the item number of interest in the table of contens. 
## Output: list(loc_item = loc_item, item_id = item_id, item = c(regex1, regex2))
##    loc_item: the location of the item with the starting and ending index. 
##    item_id: the link href for the item. 
##    item: the regex for the identified item. 
#     
## particularly item 7 and item 7A: MD&A and others 

loc.item_MDnA  <- function(x, # filing in raw data 
                           filing_type = "10-K", # filing type from the previous input
                           regex_item = c(NA, "(?=.*management)(?=.*discussion)(?=.*analysis)(?=.*operation)"), # item header 
                           regex_num = c("[>](Item|ITEM)[^0-9]+2\\.", "[>](Item|ITEM)[^0-9]+7\\."), # item number 
                           regex_perl = TRUE 
) { 
  # locate the section of the item of interest 
  ## > item 2 in 10-Q: "Unregistered Sales of Equity Securities and Use of Proceeds" ;
  ## > item 5 in 10-K: "Market for Registrant&rsquo;s Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities" ;
  ## > item 7 in 10-K: "MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS""
  
  regex1 <- regex_item[filing_type == c("10-Q", "10-K")] # identify the regex 
  regex2 <- regex_num[filing_type == c("10-Q", "10-K")] # identify the regex for item
  
  ## <Find item_id in the ToC> ## updated Oct 8, 2024 
  toc_tbl <- html_nodes(filing.toc(x = x), "table") %>% # tables including the toc 
    .[grepl(pattern = "item", x = ., ignore.case = T) & grepl(pattern = "href", x = ., ignore.case = T)]
  ### if multiple ToCs are selected: 
  if (any(grepl(pattern = ">Part.+I", x = toc_tbl, ignore.case = T))) {
    toc_tbl_id <- which(grepl(pattern = regex1, x = toc_tbl, ignore.case = T, perl = regex_perl) )[1] # locate the table for TOC: will return NA if there are no tables in toc_tbl
    if (is.na(toc_tbl_id)) {
      ## double check using `regex2` if the previous one returns NA. 
      toc_tbl_id <- which(grepl(pattern = regex2, x = toc_tbl, ignore.case = T, perl = regex_perl) )[1] # locate the table for TOC: will return NA if there are no tables in toc_tbl
      # regex1 <- regex2
    }
  } else {
    toc_tbl_id <- which(grepl(pattern = "SIGNATURE|EXHIBIT", x = toc_tbl, ignore.case = T))[1] # locate the table for TOC: will return NA if there are no tables in toc_tbl
  }
  
  # if such table exists & contains url 
  if (isTRUE(grepl(pattern = "href", x = toc_tbl[[toc_tbl_id]], ignore.case = T))) { 
    ## find the row of item in the TOC
    toc_row <- html_nodes(toc_tbl[[toc_tbl_id]], "tr") %>% # separate each row
      .[grep(pattern = "^(Item|ITEM|\\d)", x = html_text(., trim = T), ignore.case = T)]
    toc_row_id <- grep(pattern = regex1, x = html_text(toc_row), ignore.case = T, perl = regex_perl)[1] # separate and identify the row
    
    if (is.na(toc_row_id)) { 
      ## if `regex1` does not work, re-check using `regex2`: 
      toc_row_id <- grep(pattern = regex2, x = (toc_row), ignore.case = T, perl = regex_perl)[1] 
    }
    
    ## find the id for the item  ## updated July 16, 2023
    if (!is.na(toc_row_id)) { # if this item exists in the toc 
      item_id1 <- grep("#.+", html_attr(html_nodes(toc_row[toc_row_id], "a"), "href"), value = T)[1]
      if (!grepl('#', item_id1)) {
        # if such id does not exist > 
        item_id <- rep(NA, 2)
      } else {
        ### search for the id for the next item. ## udpated Sept 23, 2024 
        ### check whether the ToC has multiple components ## updated July 16, 2023 
        ### In some cases, one ToC is broken into multiple <table>...</table>s. 
        if (toc_row_id == length(toc_row)) {
          #### re-find all tables for the ToC
          toc_tbl_ids <- which(grepl(pattern = ">Part.+I|SIGNATURE", x = toc_tbl, ignore.case = T) )
          #### combine all tables into one and re-search for the item of interest 
          #### record all id(s) in the ToC ## updated July 16, 2023 
          toc_row_all <- html_nodes(toc_tbl[toc_tbl_ids], "tr") %>% # separate each row
            .[grep(pattern = "^(Item|ITEM|\\d)|(Exhibit|SIGNATURE)", x = html_text(., trim = T), ignore.case = T)]
          item_id_all <- unique(grep("#", html_attr(html_nodes(toc_row_all, "a"), "href"), value = T)) 
          #### location the id for the next item 
          item_id2 <- item_id_all[match(item_id1, item_id_all)+1] 
        } else {
          #### otherwise, only one <table> for the ToC. 
          #### extract the id from the next "href" item. 
          item_id2 <- grep("#.+", html_attr(html_nodes(toc_row[toc_row_id+1], "a"), "href"), value = T)[1]
          if (!grepl('#', item_id2)) { 
            # check whether it is a valid "href" 
            # -> if not then replace with the next valid one 
            item_id2 <- grep('#.+', html_attr(html_nodes(toc_row[-(1:toc_row_id)], "a"), "href"), value = T)[1] ## updated July 16, 2023 
          }
          
        } ## updated July 16, 2023  
        
        if (item_id1 == item_id2 & !is.na(item_id2)) { 
          # for some wired errors for instance: <https://www.sec.gov/Archives/edgar/data/858655/000155837017000308/hayn-20161231x10q.htm#Toc>
          item_id1 <- grep("#.+", html_attr(html_nodes(toc_row[toc_row_id], "a"), "href"), value = T)[2]
        }
        
        item_id <-  sub(pattern = '#', replacement = '', x = c(item_id1, item_id2))
        
        ## add a backup id ## updated August 8, 2023 
        item_id_backup <- grep('#.+', html_attr(html_nodes(toc_row[-(1:(toc_row_id))], "a"), "href"), value = T)[2:3] %>% ## updated August 8, 2023 
          sub(pattern = '#', replacement = '', x = .) 
      }
    } else { 
      # if a valid `toc_row_id` cannot be found. 
      item_id <- rep(NA, 2) 
    }
  } else {
    item_id <- rep(NA, 2)
  }
  
  ## <What if an url is found.>  
  if ( ifelse(any(is.na(item_id)), FALSE, item_id[1] != item_id[2]) ) { 
    # locate the item if item_id (url) is found ## updated July 15, 2023 ----
    
    if (any(nchar(item_id) >= 3)) {
      ## if the id is in the acceptable length
      loc_item <- vapply(X = item_id,
                         FUN = function(p) {
                           loc_item0 <- grep(pattern = paste("[<].+=(\"|\')", gsub("\\W", "\\\\\\W", p), "(\"|\')", sep = "")[1], x = x)
                           return(ifelse(length(loc_item0) != 1, loc_item0[2], loc_item0[1]))
                         },
                         FUN.VALUE = numeric(1))
    } else {
      ## if only the num of characters is too few in the id 
      x_text_id <- grep(pattern = '<text>|</text>', x = x, ignore.case = T)[1:2] # identify the main body 
      ## extract all attributes in each part of the text  
      x_text_attr <- lapply(x_text_id[1]:x_text_id[2], FUN = function(id) {
        res_attr <- try(html_attrs(html_nodes(read_html(x[id]), "a")), silent = T)
        ifelse(inherits(res_attr, "try-error"), output <- NA,
               ifelse(is.null(unlist(res_attr)[1]), output <- NA, output <- unlist(res_attr)) )
        return(output)
      } )
      ## find the paragraph containing matched id(s) 
      loc_item <- sapply(item_id, 
                         FUN = function(id) {
                           which(sapply(x_text_attr, 
                                        FUN = function(x) any(grepl(pattern = paste("^", id, "$", sep = "")[1], x))))[1]
                         } 
      ) + x_text_id[1] - 1
    }
    
    ## if the issue has not been resolved. 
    ## if they are wrongly directed to the same element in `filing / x`. > searching with brutal force: 
    if ( ifelse(any(is.na(loc_item)), TRUE, diff(loc_item) <= 0 & nchar(x[loc_item[1]]) < 5000) ) { ## updated July 15, 2023 ----
      
      ## this part is exactly the same as the following part > brutal force
      x_text <- sapply(X = x, FUN = function(x) {
        res <- try(output <- html_text(read_html(x), trim = TRUE), silent = T) 
        ## if e.g. `x = "</div></div>"`
        if (inherits(res, "try-error")) { output <- "" } 
        return(output) 
      }, simplify = TRUE, USE.NAMES = FALSE) 
      
      ## look for all the items 
      loc_item1 <- tail(grep(pattern = regex1, # paste("(", regex1, "|", regex2, ")", sep = "")[1],
                             x = x_text, ignore.case = TRUE, perl = TRUE), 1)  # find the last match, as it is more likely to be the item title. 
      # loc_item1_check <- tail(grep(pattern = ">Part.+\\bII\\b", x = x, ignore.case = T), 1) # record the Part II section in the filing
      ## check whether the 1st location is found
      if (length(loc_item1) > 0 ) { # if the first is identified # & length(loc_item1_check) > 0
        # if (loc_item1 >= loc_item1_check) { # if the place is correct 
        loc_item2 <- grep(pattern = "(>)?(Item|ITEM)[^0-9]+\\d{1}[A-Z]?[.]",
                          x = x[(loc_item1+1):grep(pattern = '<text>|</text>', x = x, ignore.case = T)[2]],
                          ignore.case = T, perl = regex_perl)[1] + loc_item1 # absorb the case without '>'. 
        
        if (is.na(loc_item2)) { # if it returns NA
          loc_item2 <- grep(pattern = "(>)?(Item|ITEM)",
                            x = x[(loc_item1+1):grep(pattern = '<text>|</text>', x = x, ignore.case = T)[2]],
                            ignore.case = F, perl = regex_perl)[1] + loc_item1 # absorb the case without '>'. 
        } ## have a second try if `loc_item2` is NA. 
        ifelse(is.na(loc_item2), loc_item <- rep(loc_item1, 2), loc_item <- c(loc_item1, loc_item2))
        
        # } else {
        #   loc_item <- rep(NA, 2)
        # }
      } else { # if the first is not identified
        loc_item <- rep(NA, 2)
      }
    }
    
    
  } else { # if no url or link/identifier is found 
    ## look for all the items 
    loc_item1 <- tail(grep(pattern = regex1, # paste("(", regex1, "|", regex2, ")", sep = "")[1],
                           x = x, ignore.case = TRUE, perl = regex_perl), 1)  # find the match
    # loc_item1_check <- tail(grep(pattern = ">Part.+\\bII\\b", x = x, ignore.case = T), 1) # record the Part II section in the filing
    ## check whether the 1st location is found
    if (length(loc_item1) > 0 ) { # if the first is identified # & length(loc_item1_check) > 0 ## updated July 16, 2023
      if (loc_item1 == length(x)) {
        loc_item <- rep(loc_item1, 2)
      } else {
        # if (loc_item1 >= loc_item1_check) { # if the place is correct 
        loc_item2 <- grep(pattern = "(>)?(Item|ITEM)[^0-9]+\\d{1}[A-Z]?[.]",
                          x = x[(loc_item1+1):grep(pattern = '<text>|</text>', x = x, ignore.case = T)[2]],
                          ignore.case = T, perl = regex_perl)[1] + loc_item1 # absorb the case without '>'.  
        
        if (is.na(loc_item2)) { # if it returns NA
          loc_item2 <- grep(pattern = "(>)?(Item|ITEM)",
                            x = x[(loc_item1+1):grep(pattern = '<text>|</text>', x = x, ignore.case = T)[2]],
                            ignore.case = F, perl = regex_perl)[1] + loc_item1 # absorb the case without '>'. 
        }
        
        ## have a second try if `loc_item2` is NA. 
        ifelse(is.na(loc_item2), loc_item <- rep(loc_item1, 2), loc_item <- c(loc_item1, loc_item2))
      } 
      
    } else { # if the first is not identified
      loc_item <- rep(NA, 2)
    }
  }
  
  ## return the location, id, and item number (i.e. item 2 or 5)
  return(list(loc_item = loc_item, item_id = item_id, item = c(regex1, regex2)))
}