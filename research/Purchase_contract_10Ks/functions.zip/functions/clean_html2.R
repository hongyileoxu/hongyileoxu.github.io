# c2. clean_html2():  ---- 
# clean the raw files and isolating <table> in the raw html text. 
# link to function `clean_html()`. 
#
## Arg: 
##    input_string: one string with contents from `readLines()`. 
##    pattern: the regular expression used to match closing tags (</...>)
##      -: [ ]"</[a-zA-Z]+>\\s*</[a-zA-Z]+>\\s*<[^/]"
##      -: [ ]"(<\\/[a-zA-Z]+>\\s*<\\/[a-zA-Z]+>\\s*)<([^/])" 
##      -: [!] "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])" # the one used in this task 
##      -: [!] "(</\\w+\\s*>\\s*)<([^/>]+>\\s*<[^/>]+>)" # also the one used in the task 
##          |_  third and fourth are combined into: c("(</\\w+\\s*>\\s*)<([^/>]+>\\s*<[^/>]+>)", 
##                                                   "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])") 
## Output: 
##    result: the cleaned vector of strings. 
# 

clean_html2 <- function(input_string, 
                        pattern = c("(</\\w+\\s*>\\s*)<([^/>]+>\\s*<[^/>]+>)",
                                    "(</[^>]+>\\s*</[^>]+>\\s*)<([^/])") ) {
  # first isolate the contents in the <table>...</table> 
  input_components <- input_string %>% 
    gsub("<(table|TABLE|Table)", "~TB~<\\1", x = .) %>% 
    gsub("</(table|TABLE|Table)>", "</\\1>~TB~", x = .) %>% 
    strsplit(x = ., split = "~TB~", fixed = T) %>%
    unlist() 
  
  # for each component without <table>, apply the function clean_html()
  result <- sapply(X = input_components, FUN = function(x) {
    if (!grepl(pattern = "<(table|TABLE|Table)", x)) {
      ## if x is not a table
      output <- as.vector(clean_html(x, pattern = pattern))
      # output[grep(pattern = "<[^/]", x = output, invert = T)] <- "<p></p>"
    } else {
      ## return the raw text for the table
      output <- x  # Corrected 'ouptut' to 'output'
    }
    return(output)
  }, USE.NAMES = FALSE) %>% unlist()
  
  
  return(result)
}