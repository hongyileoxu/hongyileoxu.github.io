# [deprecated]


## choose a different name [!] 
text_to_table(text = )

filing.item_subsection() 


## if no valid `item_tbl_id` can be identified: 
## e.g. Apple 10K in 2021: https://www.sec.gov/Archives/edgar/data/320193/000032019321000105/aapl-20210925.htm#icffec2d5c553492089e1784044e3cc53_76
# print("No Table!")
## print("k5")
## Oct 9, 2024 

### get the cleaned text in blocks. 
#### cleaned html txt blocks. 
filing_item7_rawhtml <- as.character(item_html) %>%
  clean_html2(input_string = ., pattern = "(</[^>]+>\\s*</[^>]+>\\s*)<([^/!])") 
#### extract the text from the html blocks. 
filing_item7_txt <- filing_item7_rawhtml %>%  
  sapply(X = ., FUN = function(x) html_text(read_html(x), trim = TRUE) ) %>% 
  as.vector() # %>% # store the txt excl. table
# .[. != ""] # remove empty elements in the vector

#### count the number of words in each block and identify the block as the sub-item header. 
filing_item7_txtcount <- filing_item7_txt %>% 
  str_count(string = ., pattern = "[a-zA-Z]+")
filing_item7_txtcount[grepl(pattern = "^(\\W)*[a-z]|(\\|)|^[0-9\\s]+$|([Tt]able [Oo]f)|[;$]", x = filing_item7_txt) | (filing_item7_txtcount == 0)] <- -1 # exclude strings with (1) "|", (2) not starting with capital letter or (3) no text count. 
filing_item7_headerid <- which(filing_item7_txtcount <= 8 & filing_item7_txtcount > 0) # the row id (relative to `filing_item7_txt`) for potential headers, including sub-headers. 
# filing_item7_txt[filing_item7_headerid]

{
  # #### extract the html attributes for all nodes in each html block. 
  # filing_item7_attributes <- filing_item7_rawhtml[filing_item7_headerid] %>% 
  #   sapply(X = .,
  #          FUN = function(x) 
  #            unique(na.omit(html_attr(html_elements(read_html(x), "*"), name = "style"))) %>% 
  #            paste(collapse = ";") %>% 
  #            gsub(pattern = ";padding[^;]+;", replacement = ";", x = .) %>% 
  #            gsub(pattern = ";;", replacement = ";", x = ., fixed = T),
  #          USE.NAMES = FALSE)
  # #### record the all headers and their locations in the raw html file. 
  # filing_item7_allheaders <- sapply(X = unique(filing_item7_attributes), 
  #        FUN = function(x) 
  #          cbind(
  #            name = filing_item7_txt[filing_item7_headerid[which(filing_item7_attributes == x)]], 
  #            rowid = filing_item7_headerid[which(filing_item7_attributes == x)]
  #          ) ) 
  # #### record just the sub-headers and their locations in the raw html file. 
  # filing_item7_subheaders <- filing_item7_allheaders %>% 
  #   # subitem_regex = "accounting"
  #   .[grep(x = ., pattern = "accounting", ignore.case = T)] %>%  # as the disclosure on "Critical accounting judgments" is required. 
  #   do.call(what = rbind, args = .)
  #     
  # #### the table of contents for the item (not the full filing, just the item. e.g. Item 7.) 
  # #### `filing_item7_toc` contains information for the name, the row id and an identifier for each paragraph/section header. 
  # filing_item7_toc <- do.call(what = rbind, args = filing_item7_allheaders) %>% 
  #   as_tibble() %>% 
  #   mutate(rowid = as.integer(rowid)) %>% 
  #   arrange(rowid) %>% 
  #   mutate(headeryes = (name %in% filing_item7_subheaders[, "name"]) ) 
} # [deprecated] 

### extract the relevant item (purchase obligation/contract/etc.) and its number(s)  
### keep the sentences in the paragrpah if it contains numbers or e.g. "Note 9"
filing_item7_extracted <- filing_item7_extract(filing_txt = filing_item7_txt,
                                               filing_headerid = filing_item7_headerid,
                                               item_regex = item_regex) 

### extract the text and convert information into a table format 
if (!is.null(filing_item7_extracted)) {
  ## if matched text is found 
  # e.g. https://www.sec.gov/ix?doc=/Archives/edgar/data/1543151/000154315124000012/uber-20231231.htm > [Uber Tech. > Purchase Commitment in Text]
  
  ## convert full sentences into tokens and return a matrix. 
  ## tokens in the same row of the matrix come from the same sentence. 
  filing_item7_tokens <- sapply(X = filing_item7_extracted, FUN = function(x) {
    ## first, identify the sentence with the matched info by `item_regex`. 
    text <- grep(pattern = item_regex, x = x, ignore.case = TRUE, perl = TRUE, value = TRUE) 
    ## convert the full sentence into a vector of text tokens. 
    text_vector <- str_split(string = text, pattern = "[:blank:]+") 
  }, USE.NAMES = TRUE, simplify = TRUE) %>% 
    ## convert the list of vectors into a matrix using function `vectors_to_matrix()`
    vectors_to_matrix(vec_list = .) 
  
  ## correct the row names for each item / the row name in the matrix `filing_item7_tokens`.  
  wrongnameid <- grep(pattern = paste(str_extract_all(string = item_regex, pattern = "\\w+", simplify = TRUE),
                                      collapse = "|" ), 
                      x = rownames(filing_item7_tokens), 
                      ignore.case = TRUE, perl = TRUE, value = FALSE, invert = TRUE) 
  ### if there are irregular row-names (sub-item names) -> replace it by the name from the paragraph. 
  if (length(wrongnameid) > 0) { 
    ## update the irregular row names 
    rownames(filing_item7_tokens)[wrongnameid] <- 
      filing_item7_tokens[wrongnameid,,drop = F] %>% 
      apply(MARGIN = 1, FUN = function(x) { 
        ## get the location of matched words 
        ids <- grep(pattern = gsub(pattern = "\\W+", replacement = "|", x = item_regex) %>%
                      gsub("^\\||\\|$", "", x= .), 
                    x = x, ignore.case = TRUE, perl = TRUE, value = FALSE) 
        ## enrich the text by adding the one word before the matched words 
        full_ids <- c(min(ids) - 1, ids) 
        ## return the full text outputs 
        output <- paste(x[full_ids] , collapse = " ")
        return(output) 
      }) %>% as.vector() 
  }
  
  ## extract the content numbers from the text. 
  largeunits_regex <- "thousand|milli|bill|tril" # regex to identify the number units. 
  ## classify and tabulate numbers (from text!!!)
  ## output: `tbl_numbers_fromtext` is a matrix 
  tbl_numbers_fromtext <- 
    sapply(X = 1:nrow(filing_item7_tokens), FUN = function(x) {
      text <- filing_item7_tokens[x,]
      var_name <- rownames(filing_item7_tokens)[x] 
      ## function `text_to_table()` pick the dollar values. 
      result <- text_to_table(text = text, var_name = var_name, largeunits_regex = largeunits_regex)
      return(result) 
    }, simplify = F) %>% 
    do.call(what = rbind, args = .) 
  
  if (dim(tbl_numbers_fromtext)[2] == 4) {
    ## if the output is what we want! 
    ## continue my quest: Oct 12, 2024 ---- 
    tbl_numbers_cleaned <- tbl_numbers_fromtext %>% 
      mutate(unit = gsub("\\W", "", unit)) 
    
    item_table_unit <- unique(tbl_numbers_cleaned$unit) 
    
    ## final outputs  
    return(list(table = as.matrix(tbl_numbers_cleaned), # cbind.data.frame(tbl_numbers_cleaned, unit = item_table_unit) 
                parts = filing_item7_txt, # a word vector for the whole section7. 
                table_unit = item_table_unit, 
                table_html_code = filing_item7_extracted)) # a list containing text information. 
    
  } else {
    ## if the output does not include anything. 
    return()
    
  }
  
} else {
  ## if no matched text is found 
  ## e.g. in this case. CIK: 1730168; Year: 2022; 
  #   (6) https://www.sec.gov/ix?doc=/Archives/edgar/data/0001730168/000173016823000096/avgo-20231029.htm 
  ## [Broadcom Inc. > The table is not under Item 7, but under Note 13.] 
  
  
  
}