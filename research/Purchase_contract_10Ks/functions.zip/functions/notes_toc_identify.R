# notes_toc_identify(): ----
# For a given Item 8 HTML, extract the Table of Contents for the Notes. 
# Mainly used in function `filing.item8_notes()` 
# (1) the name "Note" appears for each note section. 
# (2) the name "Note" does not appear. 
#  |- (2a) use the numbering system: (11.) > E.g. https://www.sec.gov/ix?doc=/Archives/edgar/data/822416/000082241619000008/a201810-k.htm
#  |- (2b) just use the number: 2. > E.g. https://www.sec.gov/Archives/edgar/data/8192/000162828019001107/exc-20181231x10k.htm#s83ADB6A6C29D5882B7F9A63D4128164E
# 
## Arg: 
##    x: Character. The text file in characters. Use the `filing_structured` rather than the `filing`. 
##       The end of each element of the given character should be a closing tag. 
##    loc_item: the location of the item of interest and should be a vector containing two numerical values. 
##       *this input is generated from function `loc.item_MDnA()` or `loc.item()` 
##    item_regex: character: the regex to identify the content of interest. 
##    note_regex: character: the regex to identify the Note of interest. 
##
## Output: 
##    subnote_rawhtml: list: a list of vectors with each element of the list corresponding to the Note of 
##       interest and the name of each element corresponding to the name of that Note. 
##       
# 

notes_toc_identify <- function(note_pattern = "^note \\d{1,2}", # pattern to identify the Note headers in Item 8 
                               note_pattern_extract = "(?i)^.*?note", # the regex to extract the raw HTML information from matched notes
                               item_rawhtml, # a vector of raw HTML characters in Item 8 
                               max.nloop = 3 # maximum number of loops to check the ToC  
                               ) {
  
  #### extract the text from the html blocks. 
  item_rawtxt <- sapply(X = item_rawhtml, FUN = function(x) {
    res <- try(output <- html_text(read_html(x), trim = TRUE), silent = T) 
    ## if e.g. `x = "</div></div>"`
    if (inherits(res, "try-error")) { output <- "" } 
    return(output) 
  }) %>% 
    as.vector() # %>% # store the txt excl. table 
  
  ## defaults:  
  nloop <- 0; notes_tocid_new <- NA; 
  while (length(notes_tocid_new) > 0) {
    ## go back to the case if no id is identified. 
    ## "2019/QTR1/20190131_10-K_edgar_data_755001_0001193125-19-023132.txt"
    
    ## extract the location id of identified note headers
    notes_tocid <- grep(pattern = note_pattern, x = item_rawtxt,
                        ignore.case = TRUE, perl = TRUE, value = FALSE) # location 
    
    if (length(notes_tocid) == 0) {
      ## if no `notes_tocid` is found. 
      cat("Warning: No Notes Found!")
      return(NULL) 
    }
    
    ## manually get the regex pattern for Note(s) from identified ones in `notes_toc`. 
    note_regex_manual <- str_extract(string = item_rawhtml[notes_tocid],
                                     pattern = note_pattern_extract) %>% 
      str_squish() %>% unique() %>% 
      ### clean the spaces. 
      gsub(pattern = ">\\s*<", replacement = ">\\\\s*<", x = .) %>% 
      ### combine multiple matched patterns into one.  
      paste(collapse = "|")
    
    ## get the newly identifies `id`s for the Note(s). 
    notes_tocid_new <- grep(pattern = note_regex_manual, x = item_rawhtml, value = FALSE) %>% 
      .[!. %in% notes_tocid]
    
    ## 
    if (length(notes_tocid_new) > 0) {
      # if there exists newly identified `id`s  
      item_rawhtml[notes_tocid_new] <- 
        gsub(pattern = paste("(", note_regex_manual, ")", sep = ""), 
             replacement = "~+~\\1", x = item_rawhtml[notes_tocid_new]) %>% 
        strsplit(split = "~+~", fixed = TRUE) 
      
      #### re-generate the full HTML for the Item 8 
      item_rawhtml <- unlist(item_rawhtml)
      
      #### re-extract the text from the html blocks. 
      item_rawtxt <- sapply(X = item_rawhtml, FUN = function(x) {
        res <- try(output <- html_text(read_html(x), trim = TRUE), silent = T) 
        ## if e.g. `x = "</div></div>"`
        if (inherits(res, "try-error")) { output <- "" } 
        return(output) 
      }) %>% 
        as.vector() # %>% # store the txt excl. table 
      
    } # so the best way to write a for loop & variable `notes_tocid_new` will be used to check for convergence ---- 
    
    if (nloop < max.nloop) {
      nloop <- nloop + 1 
    } else {
      cat(paste("Loop break:", nloop))
      break 
    }
  }
  # print(nloop) 
  
  #### create the table of contents for "Note". Here is the "$Note \\d{1,2}" 
  notes_toc <- item_rawtxt[notes_tocid] # name
  
  return(list(
    item_rawhtml = item_rawhtml, 
    item_rawtxt = item_rawtxt, 
    notes_toc = notes_toc, 
    notes_tocid = notes_tocid
  ))

}


